# Editorial Dream Shop

Build a complete, high-quality luxury fashion clothing ecommerce website inspired by the editorial design, visual sophistication and premium shopping experience of leading luxury fashion houses such as Gucci.

The website must have an original brand identity, original layouts and a distinctive visual language. Use luxury fashion websites as inspiration for the overall experience, but do not copy Gucci’s logo, proprietary campaign assets or exact branded designs.

Main objective: Create a realistic, production-quality fashion storefront with premium photography, elegant typography, immersive collection pages, refined product details, smooth interactions and fully responsive desktop and mobile layouts.

Important: This phase is frontend only. Do not integrate Firebase, Supabase, a database, real authentication, payment gateways or any other backend. We will connect Firebase after the frontend is completed and approved.

⸻

1. Inspect the Project Before Making Changes

If a project already exists:
* Inspect its current framework, components, routing, dependencies, styles and existing functionality.
* Preserve working code and the existing architecture wherever possible.
* Improve the project rather than unnecessarily rebuilding it.
* Do not delete existing features or replace working components without a clear reason.

If starting from scratch, use Lovable’s supported React, TypeScript, Vite and Tailwind CSS setup, with reusable components and appropriate routing.

Before implementation, briefly identify the planned structure, then proceed to build the actual website. Do not stop at a design proposal.

2. Design Direction and Visual Identity

Create a sophisticated, editorial luxury fashion aesthetic.

Colour palette
* Warm ivory and soft white.
* Black and charcoal.
* Muted brown and natural earth tones.
* Restrained seasonal accent colours.

Typography
* Elegant serif typography for major headlines and editorial statements.
* Clean, modern sans-serif typography for navigation, product descriptions, buttons and controls.
* Carefully controlled font sizes, line heights, letter spacing and text widths.

Layout
* Generous whitespace.
* Large editorial photography.
* Balanced asymmetric compositions.
* Precise alignment and consistent spacing.
* Minimal borders and subtle separators.
* Restrained shadows and refined transitions.
* Carefully designed product cards and shopping interfaces.

Avoid generic SaaS layouts, excessive rounded cards, unnecessary gradients, excessive animation, emoji icons and crowded interfaces.

The final website must look like a credible international luxury fashion brand, not a generic ecommerce starter template.

Keep the brand name, logo and visual identity configurable so that an original fashion brand can be introduced without rebuilding the layout.

3. Global Header and Navigation

Build a polished, responsive header shared across all pages.

Desktop
* Brand wordmark positioned centrally where appropriate.
* Menu controls and shopping utilities arranged with balanced spacing.
* Navigation for Men, Women, Clothing, Shoes, Bags, Accessories, New Arrivals and Journal.
* Search, account, wishlist and shopping bag icons.
* Refined mega-menus with category links and optional editorial imagery.
* Subtle hover states and smooth opening and closing transitions.
* A transparent or overlay header on suitable campaign imagery, transitioning to a solid background when appropriate.

Mobile
* Compact header with accessible menu and shopping controls.
* Full-height or spacious slide-out navigation.
* Expandable category groups.
* Search overlay or dedicated search screen.
* Touch-friendly buttons and properly sized icons.

All navigation elements must work. Implement correct routes, keyboard accessibility, focus states, escape-key handling where appropriate and clear active states.

4. Homepage

Create a complete luxury fashion homepage with varied editorial compositions.

Include:
1. Campaign hero: Large fashion photography, concise headline, optional subtitle and clear shopping links.
2. Men’s and Women’s collections: Image-led campaign blocks.
3. Shop by category: Clothing, shoes, bags and accessories.
4. New arrivals: Curated product grid using the central mock product data.
5. Seasonal campaign: Large editorial photography with carefully positioned text.
6. Brand story: A section about style, craftsmanship, materials and creative direction.
7. Editorial journal: Selected fashion stories and campaign features.
8. Newsletter: Email input, validation and simulated subscription confirmation.
9. Footer: Shopping navigation, customer care, brand information, country selector and legal links.

Avoid repeating identical two-column layouts throughout the page. Use varied image proportions, full-width campaigns, whitespace and deliberate visual rhythm.

Hero images must fit their intended containers without stretching or awkward cropping. Use appropriate image positioning for desktop and mobile.

5. Collection and Category Pages

Create reusable page templates for:
* Shop All.
* Men.
* Women.
* Clothing.
* Shoes.
* Bags.
* Accessories.
* New Arrivals.
* Individual category and subcategory pages.

Each collection page should include:
* Page title and optional editorial introduction.
* Campaign banner where appropriate.
* Breadcrumb navigation.
* Category shortcuts.
* Responsive product grid.
* Filter and sort controls.
* Active-filter indicators and clear-all action.
* Product result count.
* Empty results state.
* Pagination or a functional load-more interaction.

Product grid: Use approximately four columns on large desktop screens, three on smaller desktops, two on tablets and two on mobile where appropriate.

Filters: Support available mock-data attributes such as Category, Size, Colour, Price range, Availability.
Sorting must support featured products, newest, price low-to-high and price high-to-low.
On mobile, filters and sorting should open in a polished bottom sheet or slide-out drawer.
All filters and sorting controls must update the displayed products rather than being decorative.

6. Product Cards

Build reusable, premium product cards containing:
* Product photography.
* Product name.
* Price and optional sale price.
* Available colour indicators.
* Wishlist control.
* Optional secondary image on hover.
* Product-detail navigation.

Use consistent image ratios, elegant text placement and restrained hover transitions.
Each product card must use its own relevant mock product data and image. Do not display the same image and product name for every item.

7. Product Detail Pages

Create a premium product detail template.
Include:
* Breadcrumb navigation.
* Large product image gallery.
* Thumbnail navigation.
* Optional image zoom or expanded gallery.
* Product name, code, price and description.
* Available colours and sizes.
* Size guide modal.
* Quantity selector where appropriate.
* Add to Bag button.
* Wishlist toggle.
* Materials and care information.
* Fit and product details.
* Delivery and returns information.
* Related products.
* Recently viewed products.

Interaction requirements:
* Changing colour must update the selected variant and relevant images when available.
* Selecting a size must visibly update the selection.
* Add to Bag must validate required selections.
* Added products must retain their selected size, colour and quantity.
* Product information must come from the shared mock-data source.

Sticky purchasing interface:
On desktop, provide an appropriate sticky purchase panel where it improves usability.
On mobile, provide a bottom purchase bar when appropriate. Respect mobile safe areas and ensure it never obscures important content or navigation.

8. Search

Implement a functional search overlay or page.
Include:
* Search input.
* Clear and close controls.
* Suggested searches.
* Matching product results.
* Search by product name, category, colour and relevant attributes.
* Empty results state.
* Links to product details and collections.
Search must operate on the local mock product data.

9. Wishlist

Implement a functional wishlist.
Users must be able to:
* Save products.
* Remove products.
* View saved products.
* Navigate from wishlist items to product details.
* Add eligible items to the shopping bag.
Keep wishlist state consistent across product cards, product details and the wishlist page.
Persist suitable frontend state in localStorage, with safe handling of missing or invalid stored data.

10. Shopping Bag

Create a complete frontend shopping-bag experience.
Include:
* Product thumbnail.
* Product name.
* Selected colour and size.
* Price.
* Quantity controls.
* Remove-item action.
* Subtotal.
* Clearly labelled estimated totals.
* Continue Shopping action.
* Proceed to Checkout action.
Implement a designed empty-bag state and a populated-bag state.
Adding products, changing quantities and removing items must update the totals immediately. Products with different variants must remain separate cart lines when appropriate.
Persist the cart using localStorage.
Do not display invented shipping charges as confirmed real prices. Any illustrative shipping calculations must be clearly identified as mock values.

11. Checkout and Account Screens

Create frontend-only screens for:
Checkout: Contact information, Delivery address, Delivery-method selection, Billing address, Order review, Mock payment-method selection, Form validation, Review-before-submit step, Mock order confirmation page.
Customer account: Sign-in, Registration, Password-reset UI, Account overview, Order history mockup, Saved addresses mockup, Profile details mockup.
These screens must be clearly treated as demonstrations.
Do not collect or transmit real payment information, passwords or other sensitive personal information. Do not imply that real payments, authentication, emails or orders have occurred.
Use simulated success states and clear frontend-only messaging.

12. Editorial and Informational Pages

Create complete, consistently styled pages for:
* Journal listing.
* Journal article details.
* About the brand.
* Craftsmanship and materials.
* Contact.
* Help centre.
* Frequently asked questions.
* Size guide.
* Delivery and returns.
* Privacy policy.
* Terms and conditions.
* Wishlist.
* Account.
* Order confirmation.
Each page must contain realistic placeholder content, meaningful layouts, correct navigation and appropriate mobile styling. Do not leave empty pages or generic headings without content.
Contact and newsletter forms should have client-side validation and simulated submission feedback.

13. Central Mock Data

Create a structured, typed data layer separate from presentation components.
Include mock data for: Products, Categories, Variants, Images, Prices, Sizes, Colours, Availability, Editorial stories, Navigation, Frequently asked questions.
Use realistic product names, descriptions and consistent currency formatting.
Use appropriate fashion imagery from available project assets or properly licensed sources. Do not use Gucci campaign images or logos as if they belong to the new brand.
Provide sensible image fallbacks. Avoid broken images, irrelevant photography and identical images across unrelated products.
Keep data access behind reusable functions or a simple frontend service layer so mock data can later be replaced with Firebase-backed data.
Do not add Firebase SDKs, credentials, database configuration or backend integrations during this phase.

14. Responsive Design

Implement dedicated responsive behaviour for desktop, tablet and mobile.
Desktop: Balanced editorial compositions, Full navigation and mega-menus, Spacious product grids, Large product galleries, Appropriate sticky purchasing elements.
Mobile: Compact navigation, Responsive campaign imagery, Readable typography, Touch-friendly controls, Functional search and filter drawers, Easy size and colour selection, Mobile-friendly cart and checkout layouts, Correct sticky-bar spacing and safe-area handling, No horizontal overflow or clipped controls.

15. Accessibility and Code Quality

* Use semantic HTML and accessible labels.
* Provide descriptive image alt text.
* Ensure keyboard accessibility and visible focus states.
* Use accessible dialogs, menus and form validation.
* Respect reduced-motion preferences.
* Use a consistent icon library such as Lucide.
* Avoid unnecessary dependencies.
* Keep components small, reusable and maintainable.
* Use TypeScript types for mock data and shared component props.
* Keep routing consistent and avoid dead links.
* Add loading, empty, error and success states where appropriate.

16. Implementation Order & Verification

Build the application following the structured stages, verifying routes, interactions, search, filter/sorting, wishlist, bag, and mobile responsiveness.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/fb9e5cf4-504f-4ca6-8b49-2a47385c0ef5).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

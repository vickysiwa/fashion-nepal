import { createFileRoute } from "@tanstack/react-router";
import { Admin } from "@/components/store/admin";
import { meta } from "@/lib/catalog";
export const Route = createFileRoute("/admin")({
  head: () => meta("Store admin"),
  component: Admin,
});

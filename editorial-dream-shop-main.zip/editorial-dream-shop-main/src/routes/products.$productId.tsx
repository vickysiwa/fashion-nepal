import { createFileRoute } from "@tanstack/react-router";
import { ProductDetail } from "@/components/store/product";
import { getProduct, meta } from "@/lib/catalog";
export const Route = createFileRoute("/products/$productId")({
  head: ({ params }) => meta(getProduct(params.productId)?.name ?? "Piece unavailable"),
  component: ProductRoute,
});
function ProductRoute() {
  const { productId } = Route.useParams();
  return <ProductDetail key={productId} id={productId} />;
}

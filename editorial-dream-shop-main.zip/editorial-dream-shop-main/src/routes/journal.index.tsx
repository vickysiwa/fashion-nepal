import { createFileRoute } from "@tanstack/react-router";
import { Journal } from "@/components/store/editorial";
import { meta } from "@/lib/catalog";
export const Route = createFileRoute("/journal/")({
  head: () => meta("The journal"),
  component: Journal,
});

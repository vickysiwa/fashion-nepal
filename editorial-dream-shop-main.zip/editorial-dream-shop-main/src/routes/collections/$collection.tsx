import { createFileRoute } from "@tanstack/react-router";
import { Collection } from "@/components/store/collection";
import { collectionLabels, meta } from "@/lib/catalog";
export const Route = createFileRoute("/collections/$collection")({
  head: ({ params }) =>
    meta(collectionLabels[params.collection] ?? params.collection.replaceAll("-", " ")),
  component: CollectionRoute,
});
function CollectionRoute() {
  const { collection } = Route.useParams();
  return <Collection key={collection} collection={collection} />;
}

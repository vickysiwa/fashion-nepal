import { createFileRoute } from "@tanstack/react-router";
import { Checkout } from "@/components/store/checkout";
import { meta } from "@/lib/catalog";
export const Route = createFileRoute("/checkout")({
  head: () => meta("Demonstration checkout"),
  component: Checkout,
});

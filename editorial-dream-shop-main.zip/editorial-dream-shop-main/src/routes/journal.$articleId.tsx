import { createFileRoute } from "@tanstack/react-router";
import { Article } from "@/components/store/editorial";
import { stories, meta } from "@/lib/catalog";
export const Route = createFileRoute("/journal/$articleId")({
  head: ({ params }) =>
    meta(stories.find((s) => s.id === params.articleId)?.title ?? "Story unavailable"),
  component: ArticleRoute,
});
function ArticleRoute() {
  const { articleId } = Route.useParams();
  return <Article id={articleId} />;
}

import { createFileRoute } from "@tanstack/react-router";
import { Wishlist } from "@/components/store/bag";
import { meta } from "@/lib/catalog";
export const Route = createFileRoute("/wishlist")({
  head: () => meta("Your wishlist"),
  component: Wishlist,
});

import { createFileRoute } from "@tanstack/react-router";
import { Account } from "@/components/store/account";
import { meta } from "@/lib/catalog";
export const Route = createFileRoute("/account")({
  head: () => meta("My account"),
  component: Account,
});

import { createFileRoute } from "@tanstack/react-router";
import { Information, informationTitles } from "@/components/store/information";
import { meta } from "@/lib/catalog";
export const Route = createFileRoute("/faq")({
  head: () => meta(informationTitles["faq"] ?? "Client services"),
  component: Page,
});
function Page() {
  return <Information page="faq" />;
}

import { createFileRoute } from "@tanstack/react-router";
import { Information, informationTitles } from "@/components/store/information";
import { meta } from "@/lib/catalog";
export const Route = createFileRoute("/contact")({
  head: () => meta(informationTitles["contact"] ?? "Client services"),
  component: Page,
});
function Page() {
  return <Information page="contact" />;
}

import { createFileRoute } from "@tanstack/react-router";
import { Payment } from "@/components/store/checkout";
import { meta } from "@/lib/catalog";
export const Route = createFileRoute("/payment/$ref")({
  head: () => meta("Scan to pay — Nepali bank QR"),
  component: PaymentPage,
});
function PaymentPage() {
  const { ref } = Route.useParams();
  return <Payment orderRef={ref} />;
}

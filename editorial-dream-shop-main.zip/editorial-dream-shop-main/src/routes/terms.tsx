import { createFileRoute } from "@tanstack/react-router";
import { Information, informationTitles } from "@/components/store/information";
import { meta } from "@/lib/catalog";
export const Route = createFileRoute("/terms")({
  head: () => meta(informationTitles["terms"] ?? "Client services"),
  component: Page,
});
function Page() {
  return <Information page="terms" />;
}

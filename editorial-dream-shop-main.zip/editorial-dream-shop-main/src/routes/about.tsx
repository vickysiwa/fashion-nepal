import { createFileRoute } from "@tanstack/react-router";
import { BrandPage } from "@/components/store/editorial";
import { meta } from "@/lib/catalog";
export const Route = createFileRoute("/about")({ head: () => meta("The maison"), component: Page });
function Page() {
  return <BrandPage craft={false} />;
}

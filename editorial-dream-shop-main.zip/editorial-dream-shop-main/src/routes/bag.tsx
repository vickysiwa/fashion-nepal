import { createFileRoute } from "@tanstack/react-router";
import { Bag } from "@/components/store/bag";
import { meta } from "@/lib/catalog";
export const Route = createFileRoute("/bag")({ head: () => meta("Shopping bag"), component: Bag });

import { createFileRoute } from "@tanstack/react-router";
import { BrandPage } from "@/components/store/editorial";
import { meta } from "@/lib/catalog";
export const Route = createFileRoute("/craftsmanship")({
  head: () => meta("Craftsmanship & materials"),
  component: Page,
});
function Page() {
  return <BrandPage craft={true} />;
}

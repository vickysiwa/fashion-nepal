import { createFileRoute } from "@tanstack/react-router";
import { Confirmation } from "@/components/store/checkout";
import { meta } from "@/lib/catalog";
import { useOrders } from "@/lib/orders";
export const Route = createFileRoute("/order-confirmation")({
  validateSearch: (s: Record<string, unknown>) => ({ ref: typeof s["ref"] === "string" ? (s["ref"] as string) : "" }),
  head: () => meta("Order received"),
  component: ConfirmationPage,
});
function ConfirmationPage() {
  const { ref } = Route.useSearch();
  const { orders } = useOrders();
  const order = orders.find((o) => o.ref === ref);
  return order ? <Confirmation order={order} /> : <Confirmation />;
}

import { createFileRoute } from "@tanstack/react-router";
import { Home } from "@/components/store/home";
import { meta } from "@/lib/catalog";
export const Route = createFileRoute("/")({
  head: () =>
    meta(
      "AUREL — A quieter kind of distinction",
      "Explore the AUREL autumn/winter collection. Considered luxury, natural materials and an enduring point of view.",
    ),
  component: Home,
});

import { createFileRoute } from "@tanstack/react-router";
import { Information, informationTitles } from "@/components/store/information";
import { meta } from "@/lib/catalog";
export const Route = createFileRoute("/size-guide")({
  head: () => meta(informationTitles["size-guide"] ?? "Client services"),
  component: Page,
});
function Page() {
  return <Information page="size-guide" />;
}

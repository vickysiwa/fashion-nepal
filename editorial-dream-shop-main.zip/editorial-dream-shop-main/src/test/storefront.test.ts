import { describe, expect, it } from "vitest";
import { products, searchProducts, inCollection, getProduct, money } from "@/lib/catalog";
import { parseStored } from "@/lib/shop-state";

describe("Storefront catalog", () => {
  it("uses unique product names, identities and photographs", () => {
    for (const field of ["id", "name", "image"] as const) {
      expect(new Set(products.map(p => p[field])).size).toBe(products.length);
    }
  });
  it("searches materials, category and colour", () => {
    expect(searchProducts("cashmere")).toHaveLength(2);
    expect(searchProducts("Burgundy").map(p => p.id)).toContain("lune-shoulder-bag");
    expect(searchProducts("bags")).toHaveLength(2);
    expect(searchProducts("no-such-piece")).toHaveLength(0);
  });
  it("filters gender, subcategories and new arrivals", () => {
    const men = products.filter(p => inCollection(p, "men"));
    expect(men.every(p => p.gender !== "women")).toBe(true);
    expect(products.filter(p => inCollection(p, "knitwear"))).toHaveLength(1);
    expect(products.filter(p => inCollection(p, "new-arrivals"))).toHaveLength(8);
    expect(money(103500)).toBe("Rs. 1,03,500");
  });
});
describe("Local shopping state validation", () => {
  it("recovers safely from missing and malformed data", () => {
    expect(parseStored(null).bag).toEqual([]);
    expect(parseStored("invalid").wishlist).toEqual([]);
    expect(parseStored("null").recent).toEqual([]);
  });
  it("retains valid variants and discards invalid products, sizes and quantities", () => {
    const p = getProduct("sculpted-wool-coat");
    if (!p) throw new Error("Expected catalog fixture");
    const valid = { id:p.id, size:"M", color:"Charcoal", quantity:2 };
    const state = parseStored(JSON.stringify({bag:[valid,{...valid,size:"invalid"},{...valid,quantity:-1},{...valid,id:"unknown"}],wishlist:[p.id,"unknown",null],recent:[p.id]}));
    expect(state.bag).toEqual([valid]);
    expect(state.wishlist).toEqual([p.id]);
    expect(state.recent).toEqual([p.id]);
  });
});
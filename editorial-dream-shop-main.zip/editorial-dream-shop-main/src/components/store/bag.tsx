import { Link } from "@tanstack/react-router";
import { Minus, Plus, Trash2, ArrowRight, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getProduct, products, money } from "@/lib/catalog";
import { useShop } from "@/lib/shop-state";
import { ProductCard } from "./product-card";
import { useState } from "react";
export function Bag() {
  const { bag, update, remove } = useShop();
  const subtotal = bag.reduce((sum, l) => sum + (getProduct(l.id)?.price ?? 0) * l.quantity, 0);
  return (
    <div className="commerce-page page-width">
      <span className="eyebrow">YOUR SELECTION</span>
      <h1>
        Shopping bag <span className="muted">({bag.reduce((n, l) => n + l.quantity, 0)})</span>
      </h1>
      {!bag.length ? (
        <div className="empty-state">
          <ShoppingEmpty />
          <h2>A little room for something exceptional.</h2>
          <p>Your shopping bag is empty.</p>
          <Button asChild>
            <Link to="/collections/$collection" params={{ collection: "all" }}>
              Discover the collection <ArrowRight />
            </Link>
          </Button>
        </div>
      ) : (
        <div className="bag-layout">
          <div>
            {bag.map((l, i) => {
              const p = getProduct(l.id);
              if (!p) return null;
              return (
                <article className="bag-line" key={`${l.id}-${l.size}-${l.color}`}>
                  <Link to="/products/$productId" params={{ productId: p.id }}>
                    <img src={p.image} alt={p.name} />
                  </Link>
                  <div>
                    <Link to="/products/$productId" params={{ productId: p.id }}>
                      <h3>{p.name}</h3>
                    </Link>
                    <p>
                      {l.color} / {l.size}
                    </p>
                    <p>{money(p.price)}</p>
                    <div className="bag-quantity">
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label={`Decrease ${p.name} quantity`}
                        onClick={() => update(i, l.quantity - 1)}
                        disabled={l.quantity === 1}
                      >
                        <Minus />
                      </Button>
                      <span>{l.quantity}</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label={`Increase ${p.name} quantity`}
                        onClick={() => update(i, l.quantity + 1)}
                      >
                        <Plus />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label={`Remove ${p.name}`}
                        onClick={() => remove(i)}
                      >
                        <Trash2 />
                      </Button>
                    </div>
                  </div>
                  <strong>{money(p.price * l.quantity)}</strong>
                </article>
              );
            })}
            <Link
              className="text-link"
              to="/collections/$collection"
              params={{ collection: "all" }}
            >
              Continue shopping <ArrowRight size={16} />
            </Link>
          </div>
          <aside className="order-summary">
            <h2>Your order</h2>
            <div>
              <span>Subtotal</span>
              <span>{money(subtotal)}</span>
            </div>
            <div>
              <span>Delivery estimate</span>
              <span>Confirmed at launch</span>
            </div>
            <div className="summary-total">
              <span>Estimated total</span>
              <span>{money(subtotal)}</span>
            </div>
            <p className="fine-print">
              Illustrative product total. No delivery charges or real payments are applied.
            </p>
            <Button asChild>
              <Link to="/checkout">
                Proceed to checkout <ArrowRight />
              </Link>
            </Button>
            <p className="fine-print">Frontend demonstration only.</p>
          </aside>
        </div>
      )}
    </div>
  );
}
function ShoppingEmpty() {
  return <Heart className="empty-icon" size={36} strokeWidth={1} />;
}
export function Wishlist() {
  const { wishlist, add } = useShop();
  const [added, setAdded] = useState<string[]>([]);
  return (
    <div className="commerce-page page-width">
      <span className="eyebrow">PIECES TO RETURN TO</span>
      <h1>Your wishlist</h1>
      <p className="muted">A considered collection of your favourite pieces.</p>
      {wishlist.length ? (
        <div className="product-grid wishlist-grid">
          {products
            .filter((p) => wishlist.includes(p.id))
            .map((p) => (
              <div key={p.id}>
                <ProductCard product={p} />
                {p.sizes.length === 1 && p.available ? (
                  <Button className="mt-4 w-full" variant="outline" onClick={() => {
                    const size = p.sizes[0]; const color = p.colors[0];
                    if (!size || !color) return;
                    add({ id:p.id, size, color, quantity:1 });
                    setAdded(ids => [...ids, p.id]);
                  }}>{added.includes(p.id) ? "Added to bag" : "Add to bag"}</Button>
                ) : (
                  <Button className="mt-4 w-full" variant="outline" asChild>
                    <Link to="/products/$productId" params={{productId:p.id}}>{p.available ? "Select your size" : "View piece"}</Link>
                  </Button>
                )}
              </div>
            ))}
        </div>
      ) : (
        <div className="empty-state">
          <Heart size={36} strokeWidth={1} />
          <h2>Keep what catches your eye.</h2>
          <p>Your saved pieces will appear here.</p>
          <Button asChild>
            <Link to="/collections/$collection" params={{ collection: "all" }}>
              Explore the collection
            </Link>
          </Button>
        </div>
      )}
    </div>
  );
}

import { Link } from "@tanstack/react-router";
import { ArrowRight, ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { images, products, stories, brand } from "@/lib/catalog";
import { ProductCard } from "./product-card";
import { Newsletter } from "./newsletter";
export function Home() {
  return (
    <>
      <section className="campaign-hero">
        <img
          src={images.campaign}
          alt="AUREL autumn collection: refined tailoring in the French countryside"
          width={1920}
          height={1024}
          fetchPriority="high"
        />
        <div className="hero-content">
          <span className="eyebrow">{brand.season}</span>
          <h1>
            AUREL
            <br />
            <em>
              A quieter kind
              <br />
              of distinction.
            </em>
          </h1>
          <p>A new season. An enduring point of view.</p>
          <div className="hero-links">
            <Button variant="outline" asChild>
              <Link to="/collections/$collection" params={{ collection: "women" }}>
                Discover women <ArrowRight />
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/collections/$collection" params={{ collection: "men" }}>
                Discover men <ArrowRight />
              </Link>
            </Button>
          </div>
        </div>
        <div className="hero-bottom">
          <span>THE ART OF EVERYDAY</span>
          <ArrowDown size={18} />
          <span>COLLECTION Nº 06</span>
        </div>
      </section>
      <section className="collection-intro">
        <span className="eyebrow">THE NEW COLLECTION</span>
        <h2>
          Instinctively timeless.
          <br />
          Distinctly AUREL.
        </h2>
        <p>
          A dialogue between heritage and the here and now.
          <br />
          Discover a wardrobe of quiet confidence.
        </p>
      </section>
      <section className="collection-duo page-width">
        <Link
          to="/collections/$collection"
          params={{ collection: "women" }}
          className="collection-feature"
        >
          <div className="collection-photo">
            <img
              src={images.women}
              loading="lazy"
              alt="Woman in an ivory cashmere knit and chocolate trousers"
              width={1024}
              height={1280}
            />
            <span className="image-caption">01 / THE WOMEN’S COLLECTION</span>
          </div>
          <div className="feature-caption">
            <h3>For her.</h3>
            <span>
              Discover women <ArrowRight size={17} />
            </span>
          </div>
        </Link>
        <Link
          to="/collections/$collection"
          params={{ collection: "men" }}
          className="collection-feature men-feature"
        >
          <div className="collection-photo">
            <img
              src={images.men}
              loading="lazy"
              alt="Man in an olive tailored coat outside the maison"
              width={1024}
              height={1280}
            />
            <span className="image-caption">02 / THE MEN’S COLLECTION</span>
          </div>
          <div className="feature-caption">
            <h3>For him.</h3>
            <span>
              Discover men <ArrowRight size={17} />
            </span>
          </div>
        </Link>
      </section>
      <section className="arrivals-section page-width">
        <div className="section-heading">
          <div>
            <span className="eyebrow">A FRESH PERSPECTIVE</span>
            <h2>New arrivals</h2>
          </div>
          <Link
            className="text-link"
            to="/collections/$collection"
            params={{ collection: "new-arrivals" }}
          >
            Explore the collection <ArrowRight size={16} />
          </Link>
        </div>
        <div className="product-grid">
          {products.slice(0, 4).map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>
      <section className="category-section page-width">
        <div className="section-heading">
          <h2>The essentials, reimagined.</h2>
          <span className="eyebrow">A WARDROBE WITHOUT SEASONS</span>
        </div>
        <div className="category-grid">
          {[
            ["Clothing", "clothing", 0],
            ["Bags", "bags", 2],
            ["Shoes", "shoes", 3],
            ["Accessories", "accessories", 9],
          ].map(([label, category, i]) => (
            <Link
              key={category}
              to="/collections/$collection"
              params={{ collection: String(category) }}
            >
              <div>
                <img
                  src={products[Number(i)]?.image}
                  alt={`${label} from the AUREL collection`}
                  loading="lazy"
                />
              </div>
              <span>
                {label}
                <ArrowRight size={16} />
              </span>
            </Link>
          ))}
        </div>
      </section>
      <section className="seasonal-campaign">
        <img src={images.campaign} alt="Golden afternoon at the maison" loading="lazy" />
        <div>
          <span className="eyebrow">THE AUTUMN EDIT</span>
          <h2>In good company.</h2>
          <p>Layers to live in. Pieces to return to.</p>
          <Link
            className="text-link"
            to="/collections/$collection"
            params={{ collection: "knitwear" }}
          >
            Discover the edit <ArrowRight size={16} />
          </Link>
        </div>
      </section>
      <section className="brand-story page-width">
        <span className="eyebrow">THE SPIRIT OF AUREL</span>
        <h2>
          Not simply made.
          <br />
          <em>Considered.</em>
        </h2>
        <div>
          <p>
            We believe the most meaningful pieces are the ones that become part of your story.
            Exceptional materials, thoughtful proportions, and a respect for the art of making.
          </p>
          <Link to="/craftsmanship" className="text-link">
            Inside the maison <ArrowRight size={16} />
          </Link>
        </div>
      </section>
      <section className="journal-section page-width">
        <div className="section-heading">
          <div>
            <span className="eyebrow">FROM OUR WORLD</span>
            <h2>The journal</h2>
          </div>
          <Link to="/journal" className="text-link">
            All stories <ArrowRight size={16} />
          </Link>
        </div>
        <div className="journal-grid">
          {stories.map((s) => (
            <Link key={s.id} to="/journal/$articleId" params={{ articleId: s.id }}>
              <img src={s.image} loading="lazy" alt={s.title} />
              <span className="eyebrow">{s.category}</span>
              <h3>
                {s.title}
                <ArrowUpRightIcon />
              </h3>
            </Link>
          ))}
        </div>
      </section>
      <Newsletter />
    </>
  );
}
function ArrowUpRightIcon() {
  return <ArrowRight size={18} />;
}

import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { faqs } from "@/lib/catalog";
import { SizeTable } from "./product";
export const informationTitles: Record<string, string> = {
  contact: "Contact the maison",
  help: "How can we help?",
  faq: "Frequently asked questions",
  "size-guide": "Find your fit",
  "delivery-returns": "Delivery & returns",
  privacy: "Privacy policy",
  terms: "Terms & conditions",
};
export function Information({ page }: { page: string }) {
  const [sent, setSent] = useState(false);
  return (
    <div className="information-page page-width">
      <aside className="service-nav">
        <span className="eyebrow">CLIENT SERVICES</span>
        {Object.entries(informationTitles).map(([id, title]) => (
          <Link key={id} to={infoPath(id)} activeProps={{ className: "active" }}>
            {title}
          </Link>
        ))}
      </aside>
      <section>
        <span className="eyebrow">AT YOUR SERVICE</span>
        <h1>{informationTitles[page]}</h1>
        {page === "contact" ? (
          <>
            <p>
              For a question about the collection, sizing or the world of AUREL, leave a note below.
            </p>
            <p className="demo-notice">
              Demonstration form. Use fictional details; your message is not stored, transmitted or
              emailed.
            </p>
            {sent ? (
              <div className="success-state" role="status">
                <h2>Thank you for your note.</h2>
                <p>Your simulated enquiry is complete. No message has been sent.</p>
                <Button variant="outline" onClick={() => setSent(false)}>
                  Write another note
                </Button>
              </div>
            ) : (
              <form
                className="contact-form"
                onSubmit={(e) => {
                  e.preventDefault();
                  setSent(true);
                }}
              >
                <div className="form-grid">
                  <label>
                    Name
                    <input required placeholder="Fictional name" />
                  </label>
                  <label>
                    Email address
                    <input required type="email" placeholder="example@example.com" />
                  </label>
                </div>
                <label>
                  Subject
                  <select>
                    <option>Collection enquiry</option>
                    <option>Sizing & fit</option>
                    <option>Care advice</option>
                    <option>Other</option>
                  </select>
                </label>
                <label>
                  Your message
                  <textarea required minLength={10} rows={5} placeholder="How may we help?" />
                </label>
                <Button type="submit">
                  Send demonstration message <ArrowRight />
                </Button>
              </form>
            )}
          </>
        ) : page === "size-guide" ? (
          <>
            <p>
              Good style begins with a good fit. Compare the measurements below with your favourite
              garment.
            </p>
            <SizeTable />
            <h2>How to measure</h2>
            <p>
              Stand naturally with a soft tape measure. Measure the chest at its fullest point, the
              waist at its narrowest point and the hips at their fullest point. These measurements
              are illustrative.
            </p>
          </>
        ) : page === "help" || page === "faq" ? (
          <>
            <p>Thoughtful assistance for every part of your experience.</p>
            <div className="faq-list">
              {faqs.map(([q, a]) => (
                <details key={q}>
                  <summary>{q}</summary>
                  <p>{a}</p>
                </details>
              ))}
            </div>
            <h2>A personal conversation</h2>
            <p>Need something more specific? We would be delighted to hear from you.</p>
            <Link className="text-link" to="/contact">
              Contact the maison <ArrowRight size={16} />
            </Link>
          </>
        ) : page === "delivery-returns" ? (
          <>
            <p className="demo-notice">
              The following policy is illustrative and does not describe a currently operating
              delivery service.
            </p>
            <h2>A thoughtful arrival</h2>
            <p>
              Delivery destinations, rates and estimated times will be confirmed before launch. In
              this demonstration, standard and express delivery are illustrative selections;
              shipping charges are not added to the order total.
            </p>
            <h2>Returns & exchanges</h2>
            <p>
              Illustrative returns window: 30 days from receipt. Pieces should be unworn, unwashed
              and returned with their original tags and packaging. Personalised items may be
              excluded. Final conditions require approval before launch.
            </p>
            <h2>Carefully packaged</h2>
            <p>
              We imagine every piece arriving with the same care with which it was conceived.
              Packaging specifications will be confirmed alongside the launch of the store.
            </p>
            <Link to="/contact" className="text-link">
              Ask a question <ArrowRight size={16} />
            </Link>
          </>
        ) : (
          <Legal terms={page === "terms"} />
        )}
      </section>
    </div>
  );
}
function infoPath(p: string) {
  switch (p) {
    case "contact":
      return "/contact";
    case "help":
      return "/help";
    case "faq":
      return "/faq";
    case "size-guide":
      return "/size-guide";
    case "delivery-returns":
      return "/delivery-returns";
    case "privacy":
      return "/privacy";
    default:
      return "/terms";
  }
}
function Legal({ terms }: { terms: boolean }) {
  return (
    <>
      <p className="fine-print">Draft for demonstration · Last updated 15 October 2026</p>
      <p className="demo-notice">
        This is placeholder legal content for an original concept storefront, not a final legal
        policy.
      </p>
      <h2>{terms ? "About this storefront" : "Your information"}</h2>
      <p>
        This website is a frontend demonstration. Shopping, checkout, account and enquiry
        interactions are simulated. No actual orders, payments, authentication or emails are
        processed.
      </p>
      <h2>{terms ? "Prices & availability" : "Local storage"}</h2>
      <p>
        {terms
          ? "Product prices in NPR, availability and product details are illustrative. They are not an offer to sell. Delivery rates, taxes and commercial terms will be confirmed before launch."
          : "Your wishlist, shopping bag and recently viewed pieces are stored locally in your browser. They are not sent to a database. You can clear them by removing this site’s browser data."}
      </p>
      <h2>{terms ? "Images & brand identity" : "Forms & account demonstrations"}</h2>
      <p>
        {terms
          ? "AUREL is an original concept identity. Campaign and product imagery was generated for this demonstration. All references to materials and craftsmanship are illustrative, not verified manufacturing claims."
          : "Forms operate only in the current browser session. Do not enter real sensitive information. Account screens do not request passwords, and checkout does not request card numbers or bank details."}
      </p>
      <h2>{terms ? "Before launch" : "Future services"}</h2>
      <p>
        Before real services are enabled, approved legal terms, privacy notices, contact details and
        any required consent mechanisms must replace this demonstration content.
      </p>
      <Link to="/contact" className="text-link">
        Contact the maison <ArrowRight size={16} />
      </Link>
    </>
  );
}

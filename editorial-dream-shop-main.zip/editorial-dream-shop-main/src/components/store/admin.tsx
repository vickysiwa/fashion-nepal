import { useMemo, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { Button } from "@/components/ui/button";
import { products, money } from "@/lib/catalog";
import { qrPayload, statusLabels, useOrders, type Order, type OrderStatus } from "@/lib/orders";

type Tab = "orders" | "products" | "bank";
const filters: (OrderStatus | "all")[] = ["all", "awaiting_payment", "pending_verification", "approved", "dispatched", "cancelled"];

export function Admin() {
  const [tab, setTab] = useState<Tab>("orders");
  const { orders, reset } = useOrders();
  const pending = orders.filter((o) => o.status === "pending_verification").length;
  const revenue = orders.filter((o) => o.status === "approved" || o.status === "dispatched").reduce((n, o) => n + o.total, 0);
  return (
    <div className="admin page-width">
      <header className="admin-head">
        <div>
          <span className="eyebrow">STORE ADMIN · DEMONSTRATION</span>
          <h1>Maison dashboard</h1>
        </div>
        <Button variant="outline" onClick={reset}>Reset demo data</Button>
      </header>
      <p className="demo-notice">Frontend demonstration. No sign-in protects this page yet; data lives only in this browser.</p>
      <div className="admin-stats">
        <div><span>Orders</span><strong>{orders.length}</strong></div>
        <div><span>Awaiting verification</span><strong>{pending}</strong></div>
        <div><span>Verified revenue</span><strong>{money(revenue)}</strong></div>
      </div>
      <nav className="admin-tabs" aria-label="Admin sections">
        {(["orders", "products", "bank"] as Tab[]).map((t) => (
          <button key={t} aria-pressed={tab === t} onClick={() => setTab(t)}>
            {t === "bank" ? "Bank QR settings" : t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </nav>
      {tab === "orders" && <Orders />}
      {tab === "products" && <Products />}
      {tab === "bank" && <Bank />}
    </div>
  );
}

function Orders() {
  const { orders, updateOrder } = useOrders();
  const [filter, setFilter] = useState<OrderStatus | "all">("all");
  const [open, setOpen] = useState<string | null>(null);
  const list = useMemo(() => orders.filter((o) => filter === "all" || o.status === filter), [orders, filter]);
  const sel = orders.find((o) => o.ref === open);
  return (
    <section>
      <div className="admin-filters">
        {filters.map((f) => (
          <button key={f} aria-pressed={filter === f} onClick={() => setFilter(f)}>
            {f === "all" ? "All" : statusLabels[f]}
          </button>
        ))}
      </div>
      {!list.length ? (
        <p className="fine-print">No orders with this status.</p>
      ) : (
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr><th>Reference</th><th>Customer</th><th>City</th><th>Total</th><th>Transaction ID</th><th>Status</th><th /></tr>
            </thead>
            <tbody>
              {list.map((o) => (
                <tr key={o.ref}>
                  <td>{o.ref}</td>
                  <td>{o.customer.name}<small>{o.customer.phone}</small></td>
                  <td>{o.address.city}</td>
                  <td>{money(o.total)}</td>
                  <td>{o.transactionId ?? "—"}</td>
                  <td><span className={`status status-${o.status}`}>{statusLabels[o.status]}</span></td>
                  <td><Button size="sm" variant="outline" onClick={() => setOpen(o.ref)}>View</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {sel && <OrderDetail order={sel} onClose={() => setOpen(null)} onUpdate={(s) => updateOrder(sel.ref, { status: s })} />}
    </section>
  );
}

function OrderDetail({ order: o, onClose, onUpdate }: { order: Order; onClose: () => void; onUpdate: (s: OrderStatus) => void }) {
  return (
    <div className="admin-detail" role="dialog" aria-modal="true" aria-label={`Order ${o.ref}`} onKeyDown={(e) => e.key === "Escape" && onClose()}>
      <div className="admin-detail-panel">
        <button className="admin-close" onClick={onClose} aria-label="Close">×</button>
        <span className="eyebrow">{new Date(o.createdAt).toLocaleString("en-GB")}</span>
        <h2>{o.ref}</h2>
        <p><span className={`status status-${o.status}`}>{statusLabels[o.status]}</span></p>
        <h3>Customer</h3>
        <p>{o.customer.name}<br />{o.customer.phone} · {o.customer.email}</p>
        <h3>Delivery</h3>
        <p>{o.address.street}, {o.address.city}<br />{o.address.district}, {o.address.province} Province<br />{o.delivery}</p>
        <h3>Items</h3>
        {o.lines.map((l, i) => (
          <p key={i} className="summary-row"><span>{l.name} · {l.color} / {l.size} × {l.quantity}</span><span>{money(l.price * l.quantity)}</span></p>
        ))}
        <p className="summary-row"><span>Delivery</span><span>{o.shipping ? money(o.shipping) : "Complimentary"}</span></p>
        <p className="summary-total"><span>Total</span><strong>{money(o.total)}</strong></p>
        <h3>Bank payment</h3>
        <p>Transaction ID: <strong>{o.transactionId ?? "Not submitted"}</strong>{o.receiptName && <><br />Receipt file: {o.receiptName}</>}</p>
        <p className="fine-print">Check your bank statement for this exact amount and reference before approving.</p>
        <div className="admin-actions">
          {o.status === "pending_verification" && <Button onClick={() => onUpdate("approved")}>Verify & approve payment</Button>}
          {o.status === "approved" && <Button onClick={() => onUpdate("dispatched")}>Mark dispatched</Button>}
          {o.status !== "cancelled" && o.status !== "dispatched" && <Button variant="outline" onClick={() => onUpdate("cancelled")}>Reject / cancel</Button>}
        </div>
      </div>
    </div>
  );
}

function Products() {
  const { overrides, setOverride } = useOrders();
  return (
    <section>
      <p className="fine-print">Edits are stored as a demonstration preview and will sync to the storefront once the backend is connected.</p>
      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead><tr><th /><th>Product</th><th>Code</th><th>Price (NPR)</th><th>In stock</th></tr></thead>
          <tbody>
            {products.map((p) => {
              const ov = overrides[p.id] ?? {};
              return (
                <tr key={p.id}>
                  <td><img src={p.image} alt="" className="admin-thumb" /></td>
                  <td>{p.name}<small>{p.category}</small></td>
                  <td>{p.code}</td>
                  <td>
                    <input aria-label={`Price for ${p.name}`} type="number" min={0} step={500} value={ov.price ?? p.price}
                      onChange={(e) => setOverride(p.id, { price: Math.max(0, Number(e.target.value) || 0) })} />
                  </td>
                  <td>
                    <input aria-label={`${p.name} in stock`} type="checkbox" checked={ov.available ?? p.available}
                      onChange={(e) => setOverride(p.id, { available: e.target.checked })} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function Bank() {
  const { bank, setBank } = useOrders();
  const [draft, setDraft] = useState(bank);
  const [saved, setSaved] = useState(false);
  const f = (label: string, k: keyof typeof bank) => (
    <label key={k}>
      {label}
      <input required value={draft[k]} onChange={(e) => { setSaved(false); setDraft((d) => ({ ...d, [k]: e.target.value })); }} />
    </label>
  );
  return (
    <section className="payment-layout">
      <form className="checkout-form" onSubmit={(e) => { e.preventDefault(); setBank(draft); setSaved(true); }}>
        <h2>Receiving Nepali bank account</h2>
        {f("Bank name", "bankName")}
        {f("Account holder name", "accountName")}
        {f("Account number", "accountNumber")}
        {f("Branch", "branch")}
        {f("Merchant / Fonepay code", "merchantCode")}
        {f("Customer instructions", "instructions")}
        <Button type="submit">Save bank settings</Button>
        {saved && <p role="status" className="fine-print">Saved. New checkout QR codes use these details.</p>}
      </form>
      <div className="qr-panel">
        <span className="eyebrow">PREVIEW · Rs. 1,000</span>
        <div className="qr-frame">
          <QRCodeSVG value={qrPayload(draft, { ref: "AUR-NP-PREVIEW", total: 1000 })} size={200} bgColor="transparent" fgColor="currentColor" />
        </div>
        <p className="fine-print">{draft.bankName} · {draft.accountNumber}</p>
      </div>
    </section>
  );
}

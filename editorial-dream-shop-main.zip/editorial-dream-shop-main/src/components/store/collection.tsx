import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { SlidersHorizontal, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { products, inCollection, collectionLabels, images, money } from "@/lib/catalog";
import { ProductCard } from "./product-card";
export function Collection({ collection }: { collection: string }) {
  const [filters, setFilters] = useState(false);
  const [category, setCategory] = useState("");
  const [size, setSize] = useState("");
  const [color, setColor] = useState("");
  const [price, setPrice] = useState(300000);
  const [available, setAvailable] = useState(false);
  const [sort, setSort] = useState("featured");
  const [limit, setLimit] = useState(8);
  const base = products.filter((p) => inCollection(p, collection));
  const result = useMemo(() => {
    const a = base.filter(
      (p) =>
        (!category || p.category === category) &&
        (!size || p.sizes.includes(size)) &&
        (!color || p.colors.includes(color)) &&
        p.price <= price &&
        (!available || p.available),
    );
    if (sort === "low") a.sort((a, b) => a.price - b.price);
    if (sort === "high") a.sort((a, b) => b.price - a.price);
    if (sort === "new") a.sort((a, b) => Number(b.isNew) - Number(a.isNew));
    return a;
  }, [base, category, size, color, price, available, sort]);
  const reset = () => {
    setCategory("");
    setSize("");
    setColor("");
    setPrice(2000);
    setAvailable(false);
  };
  const title =
    collectionLabels[collection] ??
    collection.replaceAll("-", " ").replace(/^./, (c) => c.toUpperCase());
  const active = [
    category,
    size,
    color,
    price < 300000 ? `Under ${money(price)}` : "",
    available ? "In stock" : "",
  ].filter(Boolean);
  return (
    <div className="collection-page">
      <div className="breadcrumbs page-width">
        <Link to="/">Home</Link>
        <span>/</span>
        <span>{title}</span>
      </div>
      {collection === "men" || collection === "women" ? (
        <section className="collection-banner">
          <img
            src={collection === "men" ? images.men : images.women}
            alt={`${title} autumn collection`}
          />
          <div>
            <span className="eyebrow">AUTUMN / WINTER 2026</span>
            <h1>{title}</h1>
            <p>A wardrobe of quiet confidence.</p>
          </div>
        </section>
      ) : (
        <div className="collection-title page-width">
          <span className="eyebrow">THE AUREL COLLECTION</span>
          <h1>{title}</h1>
          <p>Exceptional materials. Instinctive silhouettes. An enduring point of view.</p>
        </div>
      )}
      <div className="page-width">
        <nav className="category-shortcuts" aria-label="Collection categories">
          {[
            "all",
            "coats",
            "knitwear",
            "tailoring",
            "shirts",
            "trousers",
            "dresses",
            "bags",
            "shoes",
            "accessories",
          ].map((c) => (
            <Link
              key={c}
              to="/collections/$collection"
              params={{ collection: c }}
              activeProps={{ className: "active" }}
            >
              {c === "all"
                ? "View all"
                : c.replaceAll("-", " ").replace(/^./, (s) => s.toUpperCase())}
            </Link>
          ))}
        </nav>
        <div className="collection-toolbar">
          <span aria-live="polite">{result.length} pieces</span>
          <div>
            <Button variant="ghost" onClick={() => setFilters(true)}>
              <SlidersHorizontal size={16} />
              Filter & sort{active.length > 0 && ` (${active.length})`}
            </Button>
            <select
              aria-label="Sort products"
              value={sort}
              onChange={(e) => setSort(e.target.value)}
            >
              <option value="featured">Featured</option>
              <option value="new">Newest arrivals</option>
              <option value="low">Price: low to high</option>
              <option value="high">Price: high to low</option>
            </select>
          </div>
        </div>
        {active.length > 0 && (
          <div className="active-filters">
            {active.map((a) => (
              <span key={a}>{a}</span>
            ))}
            <Button variant="link" onClick={reset}>
              Clear all <X size={13} />
            </Button>
          </div>
        )}
        <div className="product-grid">
          {result.slice(0, limit).map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
        {!result.length && (
          <div className="empty-state">
            <h2>No pieces match your selection.</h2>
            <p>Adjust your filters to explore more of the collection.</p>
            <Button variant="outline" onClick={reset}>
              Clear all filters
            </Button>
          </div>
        )}
        {result.length > limit && (
          <div className="load-more">
            <p>
              Showing {limit} of {result.length} pieces
            </p>
            <Button variant="outline" onClick={() => setLimit((l) => l + 8)}>
              Discover more
            </Button>
          </div>
        )}
      </div>
      <Sheet open={filters} onOpenChange={setFilters}>
        <SheetContent className="filter-drawer">
          <SheetTitle className="font-display text-3xl">Refine your selection</SheetTitle>
          <SheetDescription>{result.length} pieces in your selection</SheetDescription>
          <label>
            Category
            <select
              aria-label="Category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="">All categories</option>
              {[...new Set(base.map((p) => p.category))].map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </label>
          <label>
            Size
            <select aria-label="Size" value={size} onChange={(e) => setSize(e.target.value)}>
              <option value="">All sizes</option>
              {[...new Set(base.flatMap((p) => p.sizes))].map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </label>
          <label>
            Colour
            <select aria-label="Colour" value={color} onChange={(e) => setColor(e.target.value)}>
              <option value="">All colours</option>
              {[...new Set(base.flatMap((p) => p.colors))].map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </label>
          <label>
            Maximum price: {money(price)}
            <input
              aria-label="Maximum price"
              type="range"
              min="30000"
              max="300000"
              step="5000"
              value={price}
              onChange={(e) => setPrice(Number(e.target.value))}
            />
          </label>
          <label className="checkbox-label">
            <input
              type="checkbox"
              checked={available}
              onChange={(e) => setAvailable(e.target.checked)}
            />
            In stock only
          </label>
          <label>
            Sort by
            <select aria-label="Sort by" value={sort} onChange={(e) => setSort(e.target.value)}>
              <option value="featured">Featured</option>
              <option value="new">Newest</option>
              <option value="low">Price: low to high</option>
              <option value="high">Price: high to low</option>
            </select>
          </label>
          <Button onClick={() => setFilters(false)}>Show {result.length} pieces</Button>
          <Button variant="link" onClick={reset}>
            Clear all
          </Button>
        </SheetContent>
      </Sheet>
    </div>
  );
}

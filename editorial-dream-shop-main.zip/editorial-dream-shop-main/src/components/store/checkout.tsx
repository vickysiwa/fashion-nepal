import { useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Check, ArrowRight, Copy, Clock } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { Button } from "@/components/ui/button";
import { getProduct, money } from "@/lib/catalog";
import { useShop } from "@/lib/shop-state";
import {
  deliveryOptions,
  newRef,
  provinces,
  qrPayload,
  statusLabels,
  useOrders,
  type Order,
} from "@/lib/orders";

const phoneOk = (v: string) => /^9[78]\d{8}$/.test(v.replace(/\D/g, "").replace(/^977/, ""));

export function Checkout() {
  const { bag, clear } = useShop();
  const { addOrder } = useOrders();
  const navigate = useNavigate();
  const [review, setReview] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState<Record<"delivery"|"first"|"last"|"email"|"phone"|"address"|"city"|"district"|"province", string>>({ delivery: "valley", first: "", last: "", email: "", phone: "", address: "", city: "", district: "", province: "" });
  const subtotal = bag.reduce((n, l) => n + (getProduct(l.id)?.price ?? 0) * l.quantity, 0);
  const option = deliveryOptions.find((d) => d.id === form.delivery) ?? deliveryOptions[0]!;
  const total = subtotal + option.fee;
  const field = (label: string, name: keyof typeof form, type = "text", placeholder = "Use fictional details") => (
    <label key={name}>
      {label}
      <input
        name={name}
        type={type}
        required
        value={form[name] ?? ""}
        onChange={(e) => setForm((f) => ({ ...f, [name]: e.target.value }))}
        placeholder={placeholder}
      />
    </label>
  );
  if (!bag.length)
    return (
      <div className="commerce-page empty-state">
        <h1>Your bag is empty.</h1>
        <Button asChild>
          <Link to="/collections/$collection" params={{ collection: "all" }}>
            Discover the collection
          </Link>
        </Button>
      </div>
    );
  const placeOrder = () => {
    const order: Order = {
      ref: newRef(),
      createdAt: new Date().toISOString(),
      customer: { name: `${form.first} ${form.last}`, email: form.email, phone: form.phone },
      address: { street: form.address, city: form.city, district: form.district, province: form.province },
      delivery: option.label,
      shipping: option.fee,
      lines: bag.map((l) => {
        const p = getProduct(l.id)!;
        return { ...l, name: p.name, price: p.price };
      }),
      total,
      status: "awaiting_payment",
    };
    addOrder(order);
    clear();
    navigate({ to: "/payment/$ref", params: { ref: order.ref } });
  };
  return (
    <div className="commerce-page page-width">
      <span className="eyebrow">DELIVERING ACROSS NEPAL</span>
      <h1>{review ? "Review your selection" : "Checkout"}</h1>
      <p className="demo-notice">
        Demonstration only. Payment is by Nepali bank QR in Nepalese Rupees. Use fictional details;
        nothing is transmitted and no real order is placed.
      </p>
      <div className="checkout-layout">
        <div>
          {!review ? (
            <form
              className="checkout-form"
              onSubmit={(e) => {
                e.preventDefault();
                if (!phoneOk(form.phone)) return setError("Enter a 10-digit Nepali mobile number starting with 98 or 97.");
                setError("");
                setReview(true);
                window.scrollTo({ top: 0 });
              }}
            >
              <h2>01 / Contact</h2>
              {field("Email address", "email", "email", "example@example.com")}
              {field("Mobile number", "phone", "tel", "98XXXXXXXX")}
              {error && <p className="form-error" role="alert">{error}</p>}
              <h2>02 / Delivery address in Nepal</h2>
              <div className="form-grid">
                {field("First name", "first")}
                {field("Last name", "last")}
              </div>
              {field("Street / Tole", "address")}
              <div className="form-grid">
                {field("City / Municipality", "city", "text", "e.g. Kathmandu")}
                {field("District", "district", "text", "e.g. Lalitpur")}
              </div>
              <label>
                Province
                <select
                  aria-label="Province"
                  required
                  value={form.province ?? ""}
                  onChange={(e) => setForm((f) => ({ ...f, province: e.target.value }))}
                >
                  <option value="">Select province</option>
                  {provinces.map((p) => (
                    <option key={p}>{p}</option>
                  ))}
                </select>
              </label>
              <h2>03 / Delivery</h2>
              {deliveryOptions.map((d) => (
                <label className="radio-option" key={d.id}>
                  <input
                    type="radio"
                    name="delivery"
                    checked={form.delivery === d.id}
                    onChange={() => setForm((f) => ({ ...f, delivery: d.id }))}
                  />
                  {d.label} — {d.fee ? `${money(d.fee)} (illustrative)` : "complimentary"}
                </label>
              ))}
              <h2>04 / Payment</h2>
              <label className="radio-option">
                <input type="radio" checked readOnly />
                Nepali bank QR — Fonepay, mobile banking, eSewa, Khalti
              </label>
              <p className="fine-print">Only domestic payments in NPR are accepted. No cards or international payments.</p>
              <Button type="submit">
                Review selection <ArrowRight />
              </Button>
            </form>
          ) : (
            <div className="review-panel">
              <h2>Delivery details</h2>
              <p>
                {form.first} {form.last}
                <br />
                {form.address}, {form.city}
                <br />
                {form.district}, {form.province} Province, Nepal
              </p>
              <p>
                {form.email} · {form.phone}
              </p>
              <h2>Delivery & payment</h2>
              <p>
                {option.label}
                <br />
                Nepali bank QR — generated for this exact amount on the next step
              </p>
              <Button variant="outline" onClick={() => setReview(false)}>
                Edit details
              </Button>
              <Button onClick={placeOrder}>
                Place order & pay by QR <ArrowRight />
              </Button>
            </div>
          )}
        </div>
        <aside className="order-summary">
          <h2>Order review</h2>
          {bag.map((l) => {
            const p = getProduct(l.id);
            return p ? (
              <div className="review-item" key={`${l.id}${l.size}${l.color}`}>
                <img src={p.image} alt={p.name} />
                <span>
                  {p.name}
                  <small>
                    {l.color} / {l.size} / Qty {l.quantity}
                  </small>
                </span>
                <span>{money(p.price * l.quantity)}</span>
              </div>
            ) : null;
          })}
          <div className="summary-row">
            <span>Delivery (illustrative)</span>
            <span>{option.fee ? money(option.fee) : "Complimentary"}</span>
          </div>
          <div className="summary-total">
            <span>Total payable</span>
            <strong>{money(total)}</strong>
          </div>
        </aside>
      </div>
    </div>
  );
}

function CopyRow({ label, value }: { label: string; value: string }) {
  const [done, setDone] = useState(false);
  return (
    <div className="bank-row">
      <span>{label}</span>
      <strong>{value}</strong>
      <button
        type="button"
        aria-label={`Copy ${label}`}
        onClick={() => {
          navigator.clipboard?.writeText(value).catch(() => {});
          setDone(true);
          setTimeout(() => setDone(false), 1500);
        }}
      >
        {done ? <Check size={14} /> : <Copy size={14} />}
      </button>
    </div>
  );
}

export function Payment({ orderRef }: { orderRef: string }) {
  const { orders, bank, updateOrder } = useOrders();
  const navigate = useNavigate();
  const order = orders.find((o) => o.ref === orderRef);
  const [txn, setTxn] = useState("");
  const [file, setFile] = useState("");
  const [error, setError] = useState("");
  if (!order)
    return (
      <div className="commerce-page empty-state">
        <h1>Order not found.</h1>
        <p>This demonstration order is not stored in this browser.</p>
        <Button asChild>
          <Link to="/">Return home</Link>
        </Button>
      </div>
    );
  if (order.status !== "awaiting_payment") return <Confirmation order={order} />;
  return (
    <div className="commerce-page page-width">
      <span className="eyebrow">ORDER {order.ref}</span>
      <h1>Scan to pay</h1>
      <p className="demo-notice">
        Demonstration QR. Do not transfer real money — the account shown is fictional.
      </p>
      <div className="payment-layout">
        <div className="qr-panel">
          <div className="qr-frame">
            <QRCodeSVG value={qrPayload(bank, order)} size={240} level="M" bgColor="transparent" fgColor="currentColor" />
          </div>
          <p className="qr-amount">{money(order.total)}</p>
          <p className="fine-print">
            <Clock size={12} /> Pay the exact amount and keep your transaction ID.
          </p>
        </div>
        <div className="bank-panel">
          <h2>Bank details</h2>
          <CopyRow label="Bank" value={bank.bankName} />
          <CopyRow label="Account name" value={bank.accountName} />
          <CopyRow label="Account number" value={bank.accountNumber} />
          <CopyRow label="Branch" value={bank.branch} />
          <CopyRow label="Remarks / reference" value={order.ref} />
          <ol className="pay-steps">
            <li>Open Nabil Smart, MoBank, Global Smart, Fonepay, eSewa or Khalti.</li>
            <li>Scan the QR code — amount and reference are filled for you.</li>
            <li>Confirm the transfer, then enter the transaction ID below.</li>
          </ol>
          <p className="fine-print">{bank.instructions}</p>
          <form
            className="checkout-form"
            onSubmit={(e) => {
              e.preventDefault();
              if (!/^[A-Za-z0-9-]{6,24}$/.test(txn.trim())) return setError("Enter the transaction / voucher ID from your banking app (6–24 letters or digits).");
              updateOrder(order.ref, { status: "pending_verification", transactionId: txn.trim(), ...(file ? { receiptName: file } : {}) });
              navigate({ to: "/order-confirmation", search: { ref: order.ref } });
            }}
          >
            <label>
              Transaction / voucher ID
              <input value={txn} onChange={(e) => setTxn(e.target.value)} placeholder="e.g. FPY2610160045" required />
            </label>
            <label>
              Payment screenshot (optional, stays in your browser)
              <input type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0]?.name ?? "")} />
            </label>
            {error && <p className="form-error" role="alert">{error}</p>}
            <Button type="submit">
              I have paid — submit for verification <ArrowRight />
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}

export function Confirmation({ order }: { order?: Order }) {
  return (
    <div className="confirmation page-width">
      <Check size={40} strokeWidth={1} />
      <span className="eyebrow">{order ? `ORDER ${order.ref}` : "DEMONSTRATION"}</span>
      <h1>Thank you.</h1>
      {order ? (
        <p>
          Status: <strong>{statusLabels[order.status]}</strong>
          <br />
          {money(order.total)} · Transaction ID {order.transactionId ?? "—"}
          <br />
          Our team verifies the transfer with the bank before dispatch. (Demonstration — no real
          payment or order.)
        </p>
      ) : (
        <p>No order found in this browser.</p>
      )}
      <Button asChild>
        <Link to="/collections/$collection" params={{ collection: "all" }}>
          Continue exploring <ArrowRight />
        </Link>
      </Button>
    </div>
  );
}

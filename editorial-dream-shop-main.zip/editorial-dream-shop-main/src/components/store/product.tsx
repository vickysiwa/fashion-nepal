import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Heart, Minus, Plus, Check, Maximize2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { getProduct, products, money } from "@/lib/catalog";
import { useShop } from "@/lib/shop-state";
import { ProductCard } from "./product-card";
export function SizeTable() {
  return (
    <>
      <p className="muted">Illustrative measurements in centimetres. Fit varies by style.</p>
      <table className="size-table">
        <thead>
          <tr>
            <th>Size</th>
            <th>Chest</th>
            <th>Waist</th>
            <th>Hip</th>
          </tr>
        </thead>
        <tbody>
          {[
            ["XS", "80–84", "62–66", "88–92"],
            ["S", "84–88", "66–70", "92–96"],
            ["M", "88–94", "70–76", "96–102"],
            ["L", "94–100", "76–82", "102–108"],
            ["XL", "100–106", "82–88", "108–114"],
          ].map((r) => (
            <tr key={r[0]}>
              {r.map((c) => (
                <td key={c}>{c}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      <p>
        For footwear, select your usual EU size. Measure around the fullest part of the chest and
        hips and the natural waist, without pulling the tape tight.
      </p>
    </>
  );
}
export function ProductDetail({ id }: { id: string }) {
  const p = getProduct(id);
  const { wishlist, toggleWish, add, view, recent } = useShop();
  const [size, setSize] = useState("");
  const [color, setColor] = useState(p?.colors[0] ?? "");
  const [quantity, setQuantity] = useState(1);
  const [image, setImage] = useState(p?.image ?? "");
  const [guide, setGuide] = useState(false);
  const [zoom, setZoom] = useState(false);
  const [error, setError] = useState("");
  const [added, setAdded] = useState(false);
  useEffect(() => {
    view(id);
    setSize("");
    setColor(p?.colors[0] ?? "");
    setImage(p?.image ?? "");
    setAdded(false);
  }, [id]);
  if (!p)
    return (
      <div className="empty-state">
        <h1>Piece not found</h1>
        <Link to="/collections/$collection" params={{ collection: "all" }}>
          Explore the collection
        </Link>
      </div>
    );
  const addToBag = () => {
    if (!size) {
      setError("Please select a size.");
      return;
    }
    add({ id: p.id, size, color, quantity });
    setError("");
    setAdded(true);
  };
  return (
    <div className="product-page page-width">
      <div className="breadcrumbs">
        <Link to="/">Home</Link>
        <span>/</span>
        <Link to="/collections/$collection" params={{ collection: p.category }}>
          {p.category}
        </Link>
        <span>/</span>
        <span>{p.name}</span>
      </div>
      <div className="product-detail-grid">
        <div className="gallery">
          <div className="gallery-main">
            <img src={image} alt={`${color} ${p.name}`} width={512} height={640} />
            <Button
              variant="ghost"
              size="icon"
              aria-label="Expand product image"
              onClick={() => setZoom(true)}
            >
              <Maximize2 />
            </Button>
          </div>
          <div className="gallery-thumbs">
            {[p.image, ...(p.editorial ? [p.editorial] : [])].map((src, i) => (
              <Button
                key={src}
                variant="outline"
                className={image === src ? "selected" : ""}
                onClick={() => setImage(src)}
                aria-label={`View image ${i + 1}`}
              >
                <img src={src} alt={`${p.name} view ${i + 1}`} />
              </Button>
            ))}
          </div>
        </div>
        <div className="purchase-panel">
          <span className="eyebrow">THE NEW SEASON</span>
          <h1>{p.name}</h1>
          <p className="detail-price">{money(p.price)}</p>
          <p className="product-description">{p.description}</p>
          <div className="variant-group">
            <label>
              Colour: <strong>{color}</strong>
            </label>
            <div>
              {p.colors.map((c) => (
                <Button
                  key={c}
                  variant="outline"
                  className={`colour-choice ${color === c ? "selected" : ""}`}
                  aria-label={`Select ${c}`}
                  aria-pressed={color === c}
                  onClick={() => {
                    setColor(c);
                    setImage(p.image);
                    setAdded(false);
                  }}
                >
                  <span className={`swatch swatch-${c.toLowerCase()}`} />
                  {c}
                </Button>
              ))}
            </div>
          </div>
          <div className="size-heading">
            <label>Select size</label>
            <Button variant="link" onClick={() => setGuide(true)}>
              Size guide
            </Button>
          </div>
          <div className="size-options">
            {p.sizes.map((s) => (
              <Button
                key={s}
                variant="outline"
                className={size === s ? "selected" : ""}
                aria-pressed={size === s}
                onClick={() => {
                  setSize(s);
                  setError("");
                  setAdded(false);
                }}
              >
                {s}
              </Button>
            ))}
          </div>
          {error && (
            <p role="alert" className="text-destructive">
              {error}
            </p>
          )}
          <div className="quantity-control">
            <span>Quantity</span>
            <Button
              variant="ghost"
              size="icon"
              aria-label="Decrease quantity"
              onClick={() => setQuantity((q) => Math.max(1, q - 1))}
            >
              <Minus />
            </Button>
            <span>{quantity}</span>
            <Button
              variant="ghost"
              size="icon"
              aria-label="Increase quantity"
              onClick={() => setQuantity((q) => Math.min(20, q + 1))}
            >
              <Plus />
            </Button>
          </div>
          <div className="purchase-actions">
            <Button className="add-bag" disabled={!p.available} onClick={addToBag}>
              {p.available ? (
                added ? (
                  <>
                    <Check />
                    Added to bag
                  </>
                ) : (
                  "Add to bag"
                )
              ) : (
                "Currently unavailable"
              )}
            </Button>
            <Button
              variant="outline"
              size="icon"
              aria-label="Save product to wishlist"
              aria-pressed={wishlist.includes(p.id)}
              onClick={() => toggleWish(p.id)}
            >
              <Heart className={wishlist.includes(p.id) ? "fill-current" : ""} />
            </Button>
          </div>
          {added && (
            <p role="status">
              Your piece is in the bag.{" "}
              <Link className="underline" to="/bag">
                View shopping bag
              </Link>
            </p>
          )}
          <p className="fine-print">Prices are illustrative. This is a demonstration storefront.</p>
          <div className="product-accordions">
            <details open>
              <summary>Details & materials</summary>
              <p>
                {p.material}. Carefully finished seams and a timeless silhouette. Product code:{" "}
                {p.code}.
              </p>
            </details>
            <details>
              <summary>Fit & care</summary>
              <p>
                A considered, comfortable fit. Follow the garment care label. Specialist cleaning
                recommended for tailoring and silk; hand wash cashmere cold and dry flat.
              </p>
            </details>
            <details>
              <summary>Delivery & returns</summary>
              <p>
                Delivery services will be confirmed at launch. Illustrative returns window: 30 days,
                unworn and in original packaging.
              </p>
              <Link to="/delivery-returns">Explore delivery & returns</Link>
            </details>
          </div>
        </div>
      </div>
      <section className="related-section">
        <div className="section-heading">
          <h2>In good company</h2>
          <span className="eyebrow">COMPLETE THE WARDROBE</span>
        </div>
        <div className="product-grid">
          {products
            .filter((x) => x.id !== p.id)
            .slice(0, 4)
            .map((x) => (
              <ProductCard key={x.id} product={x} />
            ))}
        </div>
      </section>
      {recent.filter((x) => x !== id).length > 0 && (
        <section className="related-section">
          <h2>Recently viewed</h2>
          <div className="product-grid">
            {recent
              .filter((x) => x !== id)
              .map((x) => {
                const item = getProduct(x);
                return item ? <ProductCard key={x} product={item} /> : null;
              })}
          </div>
        </section>
      )}
      <Dialog open={guide} onOpenChange={setGuide}>
        <DialogContent>
          <DialogTitle className="font-display text-3xl">Find your fit</DialogTitle>
          <DialogDescription>AUREL size guide</DialogDescription>
          <SizeTable />
        </DialogContent>
      </Dialog>
      <Dialog open={zoom} onOpenChange={setZoom}>
        <DialogContent className="zoom-dialog">
          <DialogTitle className="sr-only">{p.name} expanded photograph</DialogTitle>
          <DialogDescription className="sr-only">Product image</DialogDescription>
          <img src={image} alt={`${p.name} enlarged view`} />
        </DialogContent>
      </Dialog>
      <div className="mobile-purchase">
        <span>{money(p.price)}</span>
        <Button disabled={!p.available} onClick={addToBag}>
          {added ? "Added to bag" : "Add to bag"}
        </Button>
      </div>
    </div>
  );
}

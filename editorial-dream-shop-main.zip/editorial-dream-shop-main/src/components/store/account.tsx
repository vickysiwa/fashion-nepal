import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Link } from "@tanstack/react-router";
export function Account() {
  const [mode, setMode] = useState("signin");
  const [signed, setSigned] = useState(false);
  const [tab, setTab] = useState("Overview");
  const [done, setDone] = useState(false);
  return (
    <div className="account-page page-width">
      <span className="eyebrow">YOUR WORLD OF AUREL</span>
      <h1>{signed ? "My account" : "A personal connection."}</h1>
      <p className="demo-notice">
        Account demonstration only. No authentication, passwords or personal data are collected. Use
        fictional details.
      </p>
      {signed ? (
        <>
          <nav className="account-tabs">
            {["Overview", "Orders", "Addresses", "Profile"].map((t) => (
              <Button
                variant={tab === t ? "default" : "ghost"}
                onClick={() => {
                  setTab(t);
                  setDone(false);
                }}
                key={t}
              >
                {t}
              </Button>
            ))}
            <Button variant="link" onClick={() => setSigned(false)}>
              Sign out of demo
            </Button>
          </nav>
          <div className="account-content">
            {tab === "Overview" ? (
              <>
                <h2>Welcome to the maison.</h2>
                <p>Your personal space for considered selections and favourite pieces.</p>
                <Link className="text-link" to="/wishlist">
                  Explore your wishlist
                </Link>
              </>
            ) : tab === "Orders" ? (
              <>
                <h2>Your orders</h2>
                <p className="muted">Illustrative order history — no real orders.</p>
                <div className="mock-order">
                  <span>DEMO-2026-001</span>
                  <span>12 October 2026</span>
                  <span>Cashmere fringe scarf</span>
                  <span>Rs. 52,500 · Example delivered</span>
                </div>
              </>
            ) : tab === "Addresses" ? (
              <>
                <h2>Saved addresses</h2>
                <p>Example address: Alex Maison, 12 Rue Exemple, Paris, 75001, France.</p>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    setDone(true);
                  }}
                >
                  <label>
                    Demonstration address
                    <textarea required rows={3} placeholder="Enter fictional address" />
                  </label>
                  <Button>Save example address</Button>
                  {done && (
                    <p role="status">Example address updated for this demonstration session.</p>
                  )}
                </form>
              </>
            ) : (
              <>
                <h2>Profile details</h2>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    setDone(true);
                  }}
                >
                  <label>
                    Name
                    <input required defaultValue="Alex Maison" />
                  </label>
                  <label>
                    Email
                    <input type="email" required defaultValue="alex@example.com" />
                  </label>
                  <Button>Save demonstration profile</Button>
                  {done && (
                    <p role="status">
                      Profile demonstration complete. No details have been stored.
                    </p>
                  )}
                </form>
              </>
            )}
          </div>
        </>
      ) : (
        <div className="account-form-wrap">
          <div className="account-tabs">
            <Button
              variant={mode === "signin" ? "default" : "ghost"}
              onClick={() => {
                setMode("signin");
                setDone(false);
              }}
            >
              Sign in
            </Button>
            <Button
              variant={mode === "register" ? "default" : "ghost"}
              onClick={() => {
                setMode("register");
                setDone(false);
              }}
            >
              Create account
            </Button>
          </div>
          <h2>
            {mode === "reset"
              ? "Reset your access"
              : mode === "register"
                ? "Join the maison"
                : "Welcome back."}
          </h2>
          {done ? (
            <p role="status">
              Password-reset demonstration complete. No email has been sent and no password has
              changed.
            </p>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (mode === "reset") setDone(true);
                else setSigned(true);
              }}
            >
              {mode === "register" && (
                <label>
                  Name
                  <input required placeholder="Fictional name" />
                </label>
              )}
              <label>
                Email address
                <input required type="email" placeholder="example@example.com" />
              </label>
              <p className="fine-print">No password is needed for this demonstration.</p>
              <Button type="submit">
                {mode === "reset"
                  ? "Simulate reset email"
                  : mode === "register"
                    ? "Enter account demonstration"
                    : "Enter sign-in demonstration"}
              </Button>
            </form>
          )}
          <Button
            variant="link"
            onClick={() => {
              setMode("reset");
              setDone(false);
            }}
          >
            Forgot your password?
          </Button>
        </div>
      )}
    </div>
  );
}

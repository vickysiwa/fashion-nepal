import { Link, useLocation } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { Menu, Search, UserRound, Heart, ShoppingBag, ArrowRight, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { brand, collectionLabels, navigation, images, searchProducts } from "@/lib/catalog";
import { useShop } from "@/lib/shop-state";
import { ProductCard } from "./product-card";
export function StoreShell({ children }: { children: ReactNode }) {
  const location = useLocation();
  const home = location.pathname === "/";
  const [scrolled, setScrolled] = useState(false);
  const [menu, setMenu] = useState(false);
  const [search, setSearch] = useState(false);
  const [query, setQuery] = useState("");
  const [mega, setMega] = useState<string | null>(null);
  const { bag, wishlist } = useShop();
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  useEffect(() => {
    setMenu(false);
    setSearch(false);
    setMega(null);
  }, [location.pathname]);
  const overlay = home && !scrolled && !mega;
  return (
    <>
      <header
        className={`store-header ${overlay ? "overlay" : ""}`}
        onMouseLeave={() => setMega(null)}
      >
        <div className="header-main">
          <div className="header-left">
            <Button
              variant="ghost"
              size="icon"
              aria-label="Open menu"
              onClick={() => setMenu(true)}
            >
              <Menu />
            </Button>
            <span className="header-label">Explore the maison</span>
          </div>
          <Link to="/" className="wordmark" aria-label={`${brand.name} home`}>
            {brand.name}
            <small>{brand.subtitle}</small>
          </Link>
          <div className="header-utilities">
            <Button variant="ghost" size="icon" aria-label="Search" onClick={() => setSearch(true)}>
              <Search />
            </Button>
            <Button variant="ghost" size="icon" asChild className="account-icon">
              <Link to="/account" aria-label="Account">
                <UserRound />
              </Link>
            </Button>
            <Button variant="ghost" size="icon" asChild className="wishlist-icon">
              <Link to="/wishlist" aria-label={`Wishlist ${wishlist.length} items`}>
                <Heart />
                {wishlist.length > 0 && <span className="icon-count">{wishlist.length}</span>}
              </Link>
            </Button>
            <Button variant="ghost" size="icon" asChild>
              <Link
                to="/bag"
                aria-label={`Shopping bag ${bag.reduce((n, l) => n + l.quantity, 0)} items`}
              >
                <ShoppingBag />
                {bag.length > 0 && (
                  <span className="icon-count">{bag.reduce((n, l) => n + l.quantity, 0)}</span>
                )}
              </Link>
            </Button>
          </div>
        </div>
        <nav className="desktop-nav" aria-label="Main navigation">
          {navigation.map((n) => (
            <Link
              key={n}
              to="/collections/$collection"
              params={{ collection: n }}
              onMouseEnter={() => setMega(n)}
              onFocus={() => setMega(n)}
              onKeyDown={(e) => {
                if (e.key === "Escape") {
                  setMega(null);
                  e.currentTarget.blur();
                }
              }}
              activeProps={{ className: "active" }}
            >
              {collectionLabels[n]}
            </Link>
          ))}
          <Link to="/journal" onMouseEnter={() => setMega(null)}>
            Journal
          </Link>
        </nav>
        {mega && (
          <div
            className="mega-menu"
            onKeyDown={(e) => {
              if (e.key === "Escape") setMega(null);
            }}
          >
            <div>
              <span className="eyebrow">THE WORLD OF AUREL</span>
              <h3>{collectionLabels[mega]}</h3>
              <Link to="/collections/$collection" params={{ collection: mega }}>
                Discover the collection <ArrowRight size={16} />
              </Link>
            </div>
            <div>
              <span className="eyebrow">SHOP BY CATEGORY</span>
              {["clothing", "shoes", "bags", "accessories"].map((n) => (
                <Link key={n} to="/collections/$collection" params={{ collection: n }}>
                  {collectionLabels[n]}
                </Link>
              ))}
            </div>
            <div>
              <span className="eyebrow">THE EDIT</span>
              <Link to="/collections/$collection" params={{ collection: "new-arrivals" }}>
                New arrivals
              </Link>
              <Link to="/collections/$collection" params={{ collection: "knitwear" }}>
                Knitwear
              </Link>
              <Link to="/collections/$collection" params={{ collection: "coats" }}>
                The outerwear edit
              </Link>
            </div>
            <Link
              to="/collections/$collection"
              params={{ collection: mega }}
              className="mega-image"
            >
              <img src={mega === "men" ? images.men : images.women} alt="The autumn collection" />
              <span>A season of quiet distinction</span>
            </Link>
          </div>
        )}
      </header>
      <Sheet open={menu} onOpenChange={setMenu}>
        <SheetContent side="left" className="menu-drawer">
          <SheetTitle className="font-display text-3xl">AUREL</SheetTitle>
          <SheetDescription>Explore the maison</SheetDescription>
          <nav aria-label="Mobile navigation">
            {navigation.map((n) => (
              <details key={n}>
                <summary>
                  {collectionLabels[n]}
                  <ChevronDown size={18} />
                </summary>
                <Link to="/collections/$collection" params={{ collection: n }}>
                  Shop all {(collectionLabels[n] ?? n).toLowerCase()}
                </Link>
                {["coats", "knitwear", "tailoring"].map((s) => (
                  <Link key={s} to="/collections/$collection" params={{ collection: s }}>
                    {s.charAt(0).toUpperCase() + s.slice(1)}
                  </Link>
                ))}
              </details>
            ))}
            <Link to="/journal">Journal</Link>
            <Link to="/about">The maison</Link>
            <Link to="/wishlist">Wishlist ({wishlist.length})</Link>
            <Link to="/account">My account</Link>
          </nav>
        </SheetContent>
      </Sheet>
      <Dialog open={search} onOpenChange={setSearch}>
        <DialogContent className="search-dialog">
          <DialogTitle className="font-display text-3xl">Find something exceptional.</DialogTitle>
          <DialogDescription>Discover the collection</DialogDescription>
          <div className="search-input">
            <Search size={20} />
            <input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search pieces, colours, materials…"
              aria-label="Search products"
            />
            {query && (
              <Button variant="ghost" onClick={() => setQuery("")}>
                Clear
              </Button>
            )}
          </div>
          {!query ? (
            <div className="suggestions">
              <span className="eyebrow">SUGGESTED SEARCHES</span>
              {["Cashmere", "Bags", "Wool", "Silk"].map((q) => (
                <Button key={q} variant="link" onClick={() => setQuery(q)}>
                  {q}
                  <ArrowRight size={14} />
                </Button>
              ))}
            </div>
          ) : (
            <>
              <p>
                {searchProducts(query).length} results for “{query}”
              </p>
              <div className="product-grid search-grid">
                {searchProducts(query).map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
              {searchProducts(query).length === 0 && (
                <div className="empty-state">
                  <h3>No pieces found.</h3>
                  <p>Try another name, material or colour.</p>
                </div>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
      <main>{children}</main>
      <Footer />
    </>
  );
}
function Footer() {
  return (
    <footer className="store-footer">
      <div className="footer-top">
        <div className="footer-brand">
          <Link to="/" className="wordmark">
            {brand.name}
            <small>{brand.subtitle}</small>
          </Link>
          <p>
            A modern expression of timeless style.
            <br />
            Considered in every detail.
          </p>
        </div>
        <div>
          <h4>THE COLLECTIONS</h4>
          {["women", "men", "bags", "accessories", "new-arrivals"].map((n) => (
            <Link key={n} to="/collections/$collection" params={{ collection: n }}>
              {collectionLabels[n]}
            </Link>
          ))}
        </div>
        <div>
          <h4>CLIENT SERVICES</h4>
          <Link to="/contact">Contact us</Link>
          <Link to="/help">Help centre</Link>
          <Link to="/delivery-returns">Delivery & returns</Link>
          <Link to="/size-guide">Size guide</Link>
          <Link to="/faq">Frequently asked questions</Link>
        </div>
        <div>
          <h4>THE MAISON</h4>
          <Link to="/about">Our story</Link>
          <Link to="/craftsmanship">Craftsmanship</Link>
          <Link to="/journal">Journal</Link>
          <Link to="/account">My account</Link>
        </div>
      </div>
      <div className="footer-bottom">
        <label>
          Country / region{" "}
          <select aria-label="Country or region" defaultValue="Nepal">
            <option>Nepal</option>
          </select>
        </label>
        <span>© 2026 AUREL. All rights reserved.</span>
        <div>
          <Link to="/privacy">Privacy policy</Link>
          <Link to="/terms">Terms & conditions</Link>
          <Link to="/admin">Store admin</Link>
        </div>
      </div>
      <p className="footer-demo">
        An original fashion concept. Shopping and account services are demonstrations.
      </p>
    </footer>
  );
}

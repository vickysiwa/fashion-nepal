import { useState } from "react";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
export function Newsletter() {
  const [done, setDone] = useState(false);
  return (
    <section className="newsletter">
      <div>
        <span className="eyebrow">LETTERS FROM THE MAISON</span>
        <h2>A closer connection.</h2>
        <p>New collections, stories and moments from the world of AUREL.</p>
      </div>
      {done ? (
        <p role="status">
          Thank you. Your demonstration subscription is complete; no email has been sent.
        </p>
      ) : (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            setDone(true);
          }}
        >
          <label className="sr-only" htmlFor="newsletter-email">
            Email address
          </label>
          <div className="email-line">
            <input id="newsletter-email" type="email" placeholder="Your email address" required />
            <Button variant="ghost" size="icon" aria-label="Subscribe">
              <ArrowRight />
            </Button>
          </div>
          <p className="fine-print">Demonstration only. Your email is not stored or transmitted.</p>
        </form>
      )}
    </section>
  );
}

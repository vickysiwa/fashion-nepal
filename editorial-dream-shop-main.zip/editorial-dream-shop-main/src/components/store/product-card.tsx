import { Link } from "@tanstack/react-router";
import { Heart, ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { money, type Product } from "@/lib/catalog";
import { useShop } from "@/lib/shop-state";
export function ProductCard({ product: p }: { product: Product }) {
  const { wishlist, toggleWish } = useShop();
  return (
    <article className="product-card">
      <div className="product-image">
        <Link to="/products/$productId" params={{ productId: p.id }}>
          <img
            src={p.image}
            alt={`${p.colors[0]} ${p.name}`}
            loading="lazy"
            width={512}
            height={640}
          />
          {p.editorial && (
            <img
              className="secondary-image"
              src={p.editorial}
              alt={`${p.name} styled in the autumn collection`}
              loading="lazy"
            />
          )}
        </Link>
        {p.isNew && <span className="product-badge">NEW SEASON</span>}
        <Button
          variant="ghost"
          size="icon"
          className="wish-button"
          aria-label={`${wishlist.includes(p.id) ? "Remove" : "Save"} ${p.name} ${wishlist.includes(p.id) ? "from" : "to"} wishlist`}
          aria-pressed={wishlist.includes(p.id)}
          onClick={() => toggleWish(p.id)}
        >
          <Heart className={wishlist.includes(p.id) ? "fill-current" : ""} />
        </Button>
      </div>
      <Link className="product-name" to="/products/$productId" params={{ productId: p.id }}>
        {p.name}
        <ArrowUpRight size={14} />
      </Link>
      <div className="product-meta">
        <span>{p.colors.join(" / ")}</span>
        <span>{money(p.salePrice ?? p.price)}</span>
      </div>
    </article>
  );
}

import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { stories, images } from "@/lib/catalog";
import { Newsletter } from "./newsletter";
export function Journal() {
  return (
    <>
      <section className="journal-heading page-width">
        <span className="eyebrow">THE WORLD OF AUREL</span>
        <h1>The journal</h1>
        <p>Ideas, encounters and stories from the maison.</p>
      </section>
      <div className="journal-list page-width">
        {stories.map((s, i) => (
          <Link
            className={i === 0 ? "journal-lead" : ""}
            key={s.id}
            to="/journal/$articleId"
            params={{ articleId: s.id }}
          >
            <img src={s.image} alt={s.title} loading="lazy" />
            <div>
              <span className="eyebrow">{s.category}</span>
              <h2>{s.title}</h2>
              <p>{s.intro}</p>
              <span className="text-link">
                Read the story <ArrowRight size={16} />
              </span>
            </div>
          </Link>
        ))}
      </div>
      <Newsletter />
    </>
  );
}
export function Article({ id }: { id: string }) {
  const story = stories.find((s) => s.id === id);
  if (!story)
    return (
      <div className="empty-state">
        <h1>Story not found</h1>
        <Link to="/journal">Return to the journal</Link>
      </div>
    );
  return (
    <>
      <div className="article-heading">
        <Link className="eyebrow" to="/journal">
          THE JOURNAL / {story.category}
        </Link>
        <h1>{story.title}</h1>
        <p>{story.intro}</p>
        <span className="fine-print">15 October 2026 · 4 minute read</span>
      </div>
      <img className="article-cover" src={story.image} alt={story.title} />
      <article className="article-body">
        <p className="article-lede">
          There is a particular beauty in the moments between things. The last warmth of an
          afternoon, the first feeling of autumn in the air, the reassuring weight of a familiar
          coat.
        </p>
        <p>
          Our new collection begins here: not with a statement, but with a feeling. In the quiet
          landscapes of the French countryside, shapes find their ease and materials reveal their
          character. Wool carries structure without rigidity. Cashmere offers softness without
          excess. Silk brings a delicate light to the everyday.
        </p>
        <h2>A different kind of presence</h2>
        <p>
          Each piece is conceived as part of a conversation. A sculpted coat sits alongside an
          instinctive knit; a softly structured bag accompanies trousers cut with generous movement.
          They are not designed for a moment, but for the many moments that make a life.
        </p>
        <blockquote>
          “The most compelling expression of style is the one that feels entirely your own.”
        </blockquote>
        <p>
          To dress with intention is to choose what matters. To notice a proportion, appreciate a
          texture, and return to the pieces that make you feel at home in yourself. This is the
          world of AUREL.
        </p>
        <Link
          className="text-link"
          to="/collections/$collection"
          params={{ collection: "new-arrivals" }}
        >
          Discover the new collection <ArrowRight size={16} />
        </Link>
      </article>
      <Newsletter />
    </>
  );
}
export function BrandPage({ craft = false }: { craft?: boolean }) {
  return (
    <>
      <section className="brand-cover">
        <img
          src={craft ? images.men : images.campaign}
          alt={
            craft
              ? "AUREL tailoring in the countryside"
              : "The setting of the AUREL autumn campaign"
          }
        />
        <div>
          <span className="eyebrow">{craft ? "THE ART OF MAKING" : "THE MAISON"}</span>
          <h1>{craft ? "Considered. In every detail." : "AUREL"}</h1>
          <p>
            {craft
              ? "Materials with character. Craft with purpose."
              : "A modern expression of timeless style."}
          </p>
        </div>
      </section>
      <section className="article-body">
        <span className="eyebrow">{craft ? "CRAFTSMANSHIP & MATERIALS" : "OUR STORY"}</span>
        <h2>{craft ? "The beauty is in the making." : "An enduring point of view."}</h2>
        <p className="article-lede">
          {craft
            ? "From the first touch of a material to the last detail of a seam, every choice is an expression of care."
            : "AUREL is an original fashion concept exploring the space between tradition and contemporary life. Quiet by nature. Distinctive by design."}
        </p>
        <p>
          We start with simplicity, then consider every detail. The hand of a fabric. The fall of a
          shoulder. The precise proportion of a pocket. These small decisions build a language that
          does not need to raise its voice.
        </p>
        <h2>Natural character</h2>
        <p>
          Our illustrative collection celebrates wool, cashmere, mulberry silk and supple leather.
          Their textures and movement inform our silhouettes, rather than the other way around.
          Actual sourcing, production partners and certifications will be confirmed before launch.
        </p>
        <h2>Made to be part of your story</h2>
        <p>
          A thoughtful wardrobe is a personal one. We imagine pieces that can move between
          occasions, work together naturally, and invite you to make them your own.
        </p>
        <Link className="text-link" to="/collections/$collection" params={{ collection: "all" }}>
          Explore the collection <ArrowRight size={16} />
        </Link>
      </section>
    </>
  );
}

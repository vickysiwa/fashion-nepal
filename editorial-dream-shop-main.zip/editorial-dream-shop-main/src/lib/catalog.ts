import campaign from "@/assets/campaign.jpg";
import women from "@/assets/women.jpg";
import men from "@/assets/men.jpg";
import p1 from "@/assets/product-1.jpg";
import p2 from "@/assets/product-2.jpg";
import p3 from "@/assets/product-3.jpg";
import p4 from "@/assets/product-4.jpg";
import p5 from "@/assets/product-5.jpg";
import p6 from "@/assets/product-6.jpg";
import p7 from "@/assets/product-7.jpg";
import p8 from "@/assets/product-8.jpg";
import p9 from "@/assets/product-9.jpg";
import p10 from "@/assets/product-10.jpg";
import p11 from "@/assets/product-11.jpg";
import p12 from "@/assets/product-12.jpg";
export const brand = { name: "AUREL", subtitle: "MAISON DE PARIS", season: "AUTUMN / WINTER 2026" };
export const images = { campaign, women, men };
export type Product = {
  id: string;
  name: string;
  category: string;
  subcategory: string;
  gender: "men" | "women" | "unisex";
  price: number;
  salePrice?: number;
  image: string;
  editorial?: string | undefined;
  colors: string[];
  sizes: string[];
  available: boolean;
  isNew: boolean;
  description: string;
  material: string;
  code: string;
};
const rows: [string, string, string, string, Product["gender"], number, string, string, string][] =
  [
    [
      "sculpted-wool-coat",
      "Sculpted wool coat",
      "clothing",
      "coats",
      "women",
      1890,
      p1,
      "Charcoal",
      "100% virgin wool",
    ],
    [
      "cable-cashmere-knit",
      "Cable cashmere knit",
      "clothing",
      "knitwear",
      "unisex",
      690,
      p2,
      "Ivory",
      "100% cashmere",
    ],
    [
      "forme-leather-bag",
      "Le Forme leather bag",
      "bags",
      "handbags",
      "women",
      1250,
      p3,
      "Chocolate",
      "Supple calfskin leather",
    ],
    [
      "signature-loafers",
      "Signature leather loafers",
      "shoes",
      "loafers",
      "unisex",
      590,
      p4,
      "Black",
      "Calfskin leather; leather sole",
    ],
    [
      "atelier-wool-blazer",
      "Atelier wool blazer",
      "clothing",
      "tailoring",
      "men",
      1190,
      p5,
      "Olive",
      "100% virgin wool; cupro lining",
    ],
    [
      "silk-essential-blouse",
      "Silk essential blouse",
      "clothing",
      "shirts",
      "women",
      490,
      p6,
      "Ivory",
      "100% mulberry silk",
    ],
    [
      "pleated-wool-trousers",
      "Pleated wool trousers",
      "clothing",
      "trousers",
      "unisex",
      650,
      p7,
      "Chocolate",
      "100% wool",
    ],
    [
      "lune-shoulder-bag",
      "Le Lune shoulder bag",
      "bags",
      "shoulder-bags",
      "women",
      980,
      p8,
      "Burgundy",
      "Smooth calfskin leather",
    ],
    [
      "court-leather-sneakers",
      "Court leather sneakers",
      "shoes",
      "sneakers",
      "unisex",
      420,
      p9,
      "Ivory",
      "Calfskin leather; rubber sole",
    ],
    [
      "cashmere-fringe-scarf",
      "Cashmere fringe scarf",
      "accessories",
      "scarves",
      "unisex",
      350,
      p10,
      "Camel",
      "100% cashmere",
    ],
    [
      "atelier-leather-belt",
      "Atelier leather belt",
      "accessories",
      "belts",
      "unisex",
      290,
      p11,
      "Black",
      "Calfskin leather; brass buckle",
    ],
    [
      "column-silk-dress",
      "Column silk dress",
      "clothing",
      "dresses",
      "women",
      1290,
      p12,
      "Ivory",
      "100% silk",
    ],
  ];
export const products: Product[] = rows.map((r, i) => ({
  id: r[0],
  name: r[1],
  category: r[2],
  subcategory: r[3],
  gender: r[4],
  price: r[5] * 150,
  image: r[6],
  colors: [r[7]],
  material: r[8],
  sizes:
    r[2] === "clothing"
      ? ["XS", "S", "M", "L", "XL"]
      : r[2] === "shoes"
        ? ["36", "37", "38", "39", "40", "41", "42", "43", "44"]
        : ["One size"],
  available: i !== 10,
  isNew: i < 8,
  code: `AU-26-${String(i + 1).padStart(3, "0")}`,
  description:
    "A study in considered simplicity. Cut with a refined silhouette and finished with meticulous attention to detail, this piece brings effortless distinction to the everyday.",
  editorial: i === 0 || i === 1 || i === 6 ? women : i === 4 ? men : undefined,
}));
export const money = (n: number) =>
  `Rs. ${new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 }).format(n)}`;
export const getProduct = (id: string) => products.find((p) => p.id === id);
export const collectionLabels: Record<string, string> = {
  all: "All collections",
  men: "Men",
  women: "Women",
  clothing: "Clothing",
  shoes: "Shoes",
  bags: "Bags",
  accessories: "Accessories",
  "new-arrivals": "New arrivals",
};
export const navigation = [
  "women",
  "men",
  "clothing",
  "shoes",
  "bags",
  "accessories",
  "new-arrivals",
];
export const inCollection = (p: Product, c: string) =>
  c === "all" ||
  (c === "new-arrivals" && p.isNew) ||
  (c === "men" && (p.gender === "men" || p.gender === "unisex")) ||
  (c === "women" && (p.gender === "women" || p.gender === "unisex")) ||
  p.category === c ||
  p.subcategory === c;
export const searchProducts = (q: string) =>
  products.filter((p) =>
    `${p.name} ${p.category} ${p.subcategory} ${p.colors.join(" ")} ${p.material}`
      .toLowerCase()
      .includes(q.toLowerCase().trim()),
  );
export const stories = [
  {
    id: "the-art-of-stillness",
    title: "The art of stillness",
    category: "THE AUTUMN CAMPAIGN",
    image: campaign,
    intro:
      "Away from the noise, a new perspective. An autumn collection shaped by quiet landscapes and the beauty of slowing down.",
  },
  {
    id: "a-considered-wardrobe",
    title: "A considered wardrobe",
    category: "STYLE NOTES",
    image: women,
    intro:
      "Natural textures, thoughtful layers and pieces that feel as familiar as they are unexpected.",
  },
  {
    id: "the-shape-of-craft",
    title: "The shape of craft",
    category: "INSIDE THE ATELIER",
    image: men,
    intro: "An exploration of proportion, precision and the hands behind every detail.",
  },
];
export const faqs = [
  [
    "How do I choose my size?",
    "Our pieces are designed for a considered, relaxed fit. Refer to the measurements in our size guide and compare them with a garment you already love.",
  ],
  [
    "Where do you deliver?",
    "This is a demonstration storefront. Delivery destinations and service availability will be confirmed when the store launches.",
  ],
  [
    "Can I return an item?",
    "Illustrative policy: unworn items in their original packaging may be returned within 30 days. Final terms will be confirmed before launch.",
  ],
  [
    "How should I care for my pieces?",
    "Follow the individual care label. Air wool and cashmere between wears; entrust delicate silk and tailored pieces to a specialist cleaner.",
  ],
  [
    "Is my order real?",
    "No. Purchases, accounts and form submissions on this storefront are frontend demonstrations. No payments are collected and no orders or emails are sent.",
  ],
];
export function meta(
  title: string,
  description = "Discover considered luxury, refined essentials and contemporary craftsmanship at AUREL.",
) {
  return {
    meta: [
      { title: `${title} | AUREL` },
      { name: "description", content: description },
      { property: "og:title", content: `${title} | AUREL` },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  };
}

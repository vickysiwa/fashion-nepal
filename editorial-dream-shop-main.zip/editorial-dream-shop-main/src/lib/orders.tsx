import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { BagLine } from "./shop-state";

/** Demonstration order + Nepal bank settings store. Replace with backend tables later. */
export type OrderStatus = "awaiting_payment" | "pending_verification" | "approved" | "dispatched" | "cancelled";
export type Order = {
  ref: string;
  createdAt: string;
  customer: { name: string; email: string; phone: string };
  address: { street: string; city: string; district: string; province: string };
  delivery: string;
  shipping: number;
  lines: (BagLine & { name: string; price: number })[];
  total: number;
  status: OrderStatus;
  transactionId?: string;
  receiptName?: string;
};
export type BankSettings = {
  bankName: string;
  accountName: string;
  accountNumber: string;
  branch: string;
  merchantCode: string;
  instructions: string;
};
export const statusLabels: Record<OrderStatus, string> = {
  awaiting_payment: "Awaiting payment",
  pending_verification: "Pending bank verification",
  approved: "Payment approved",
  dispatched: "Dispatched",
  cancelled: "Cancelled",
};
export const provinces = ["Koshi", "Madhesh", "Bagmati", "Gandaki", "Lumbini", "Karnali", "Sudurpashchim"];
export const deliveryOptions = [
  { id: "valley", label: "Kathmandu Valley — 1–2 days", fee: 0 },
  { id: "outside", label: "Outside Valley — 3–5 days", fee: 250 },
];
export const defaultBank: BankSettings = {
  bankName: "Nabil Bank Ltd.",
  accountName: "AUREL MAISON NEPAL PVT. LTD.",
  accountNumber: "0101017500123 (demo)",
  branch: "Durbar Marg, Kathmandu",
  merchantCode: "AUREL-DEMO-001",
  instructions: "Scan with any Nepali mobile banking app, Fonepay, eSewa or Khalti and pay the exact amount.",
};
/** Text payload encoded in the QR. A real Fonepay/NepalQR merchant payload replaces this later. */
export const qrPayload = (b: BankSettings, o: Pick<Order, "ref" | "total">) =>
  JSON.stringify({ bank: b.bankName, account: b.accountNumber, name: b.accountName, merchant: b.merchantCode, amount: o.total, currency: "NPR", ref: o.ref });
export const newRef = () => `AUR-NP-${Math.floor(10000 + Math.random() * 90000)}`;

const seed: Order[] = [
  { ref: "AUR-NP-48213", createdAt: "2026-10-14T09:20:00Z", customer: { name: "Sita Shrestha", email: "sita@example.com", phone: "9841000001" }, address: { street: "Jhamsikhel Marg", city: "Lalitpur", district: "Lalitpur", province: "Bagmati" }, delivery: "Kathmandu Valley — 1–2 days", shipping: 0, lines: [{ id: "x", size: "S", color: "Ivory", quantity: 1, name: "Demo coat", price: 103500 }], total: 103500, status: "pending_verification", transactionId: "NBL260014932118" },
  { ref: "AUR-NP-51907", createdAt: "2026-10-13T14:05:00Z", customer: { name: "Aarav Gurung", email: "aarav@example.com", phone: "9856000002" }, address: { street: "Lakeside Road 6", city: "Pokhara", district: "Kaski", province: "Gandaki" }, delivery: "Outside Valley — 3–5 days", shipping: 250, lines: [{ id: "y", size: "M", color: "Charcoal", quantity: 2, name: "Demo knit", price: 52500 }], total: 105250, status: "approved", transactionId: "FPY2610130045" },
  { ref: "AUR-NP-37762", createdAt: "2026-10-11T07:40:00Z", customer: { name: "Priya Maharjan", email: "priya@example.com", phone: "9801000003" }, address: { street: "Durbar Square Rd", city: "Bhaktapur", district: "Bhaktapur", province: "Bagmati" }, delivery: "Kathmandu Valley — 1–2 days", shipping: 0, lines: [{ id: "z", size: "One size", color: "Cognac", quantity: 1, name: "Demo bag", price: 187500 }], total: 187500, status: "dispatched", transactionId: "ESW8812740021" },
];

type Store = {
  orders: Order[];
  bank: BankSettings;
  overrides: Record<string, { price?: number; available?: boolean }>;
  addOrder: (o: Order) => void;
  updateOrder: (ref: string, patch: Partial<Order>) => void;
  setBank: (b: BankSettings) => void;
  setOverride: (id: string, patch: { price?: number; available?: boolean }) => void;
  reset: () => void;
};
const Ctx = createContext<Store | undefined>(undefined);
const KEY = "aurel-orders";
export function OrdersProvider({ children }: { children: ReactNode }) {
  const [orders, setOrders] = useState<Order[]>(seed);
  const [bank, setBank] = useState<BankSettings>(defaultBank);
  const [overrides, setOverrides] = useState<Store["overrides"]>({});
  const [ready, setReady] = useState(false);
  useEffect(() => {
    try {
      const s = JSON.parse(localStorage.getItem(KEY) || "{}");
      if (Array.isArray(s.orders)) setOrders(s.orders.filter((o: Order) => o && typeof o.ref === "string" && Array.isArray(o.lines)));
      if (s.bank && typeof s.bank.bankName === "string") setBank({ ...defaultBank, ...s.bank });
      if (s.overrides && typeof s.overrides === "object") setOverrides(s.overrides);
    } catch {
      /* invalid data: keep defaults */
    }
    setReady(true);
  }, []);
  useEffect(() => {
    if (ready)
      try {
        localStorage.setItem(KEY, JSON.stringify({ orders, bank, overrides }));
      } catch {
        /* storage unavailable */
      }
  }, [orders, bank, overrides, ready]);
  return (
    <Ctx.Provider
      value={{
        orders,
        bank,
        overrides,
        addOrder: (o) => setOrders((x) => [o, ...x]),
        updateOrder: (ref, patch) => setOrders((x) => x.map((o) => (o.ref === ref ? ({ ...o, ...patch } as Order) : o))),
        setBank,
        setOverride: (id, patch) => setOverrides((x) => ({ ...x, [id]: { ...x[id], ...patch } })),
        reset: () => {
          setOrders(seed);
          setBank(defaultBank);
          setOverrides({});
        },
      }}
    >
      {children}
    </Ctx.Provider>
  );
}
export function useOrders() {
  const c = useContext(Ctx);
  if (!c) throw new Error("Orders provider missing");
  return c;
}

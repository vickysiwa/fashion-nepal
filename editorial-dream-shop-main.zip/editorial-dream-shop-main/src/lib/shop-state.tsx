import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { getProduct } from "./catalog";
export type BagLine = { id: string; size: string; color: string; quantity: number };
type Shop = {
  bag: BagLine[];
  wishlist: string[];
  recent: string[];
  toggleWish: (id: string) => void;
  add: (line: BagLine) => void;
  update: (index: number, quantity: number) => void;
  remove: (index: number) => void;
  clear: () => void;
  view: (id: string) => void;
};
const Context = createContext<Shop | undefined>(undefined);
export function parseStored(value: string | null): {
  bag: BagLine[];
  wishlist: string[];
  recent: string[];
} {
  try {
    const s = JSON.parse(value || "{}");
    return {
      bag: Array.isArray(s.bag)
        ? s.bag.filter((l: BagLine) => {
            const p = getProduct(l?.id);
            return (
              p &&
              p.sizes.includes(l.size) &&
              p.colors.includes(l.color) &&
              Number.isInteger(l.quantity) &&
              l.quantity > 0 &&
              l.quantity <= 20
            );
          })
        : [],
      wishlist: Array.isArray(s.wishlist)
        ? s.wishlist.filter((id: unknown) => typeof id === "string" && getProduct(id))
        : [],
      recent: Array.isArray(s.recent)
        ? s.recent.filter((id: unknown) => typeof id === "string" && getProduct(id))
        : [],
    };
  } catch {
    return { bag: [], wishlist: [], recent: [] };
  }
}
export function ShopProvider({ children }: { children: ReactNode }) {
  const [bag, setBag] = useState<BagLine[]>([]);
  const [wishlist, setWish] = useState<string[]>([]);
  const [recent, setRecent] = useState<string[]>([]);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    try {
      const s = parseStored(localStorage.getItem("aurel-store"));
      setBag(s.bag);
      setWish(s.wishlist);
      setRecent(s.recent);
    } catch {
      /* Storage unavailable: use session state. */
    }
    setReady(true);
  }, []);
  useEffect(() => {
    if (ready)
      try {
        localStorage.setItem("aurel-store", JSON.stringify({ bag, wishlist, recent }));
      } catch {
        /* Keep session state. */
      }
  }, [bag, wishlist, recent, ready]);
  return (
    <Context.Provider
      value={{
        bag,
        wishlist,
        recent,
        toggleWish: (id) =>
          setWish((w) => (w.includes(id) ? w.filter((x) => x !== id) : [...w, id])),
        add: (line) =>
          setBag((b) => {
            const i = b.findIndex(
              (x) => x.id === line.id && x.size === line.size && x.color === line.color,
            );
            return i < 0
              ? [...b, line]
              : b.map((x, j) =>
                  j === i ? { ...x, quantity: Math.min(20, x.quantity + line.quantity) } : x,
                );
          }),
        update: (i, q) =>
          setBag((b) =>
            b.map((x, j) => (i === j ? { ...x, quantity: Math.max(1, Math.min(20, q)) } : x)),
          ),
        remove: (i) => setBag((b) => b.filter((_, j) => i !== j)),
        clear: () => setBag([]),
        view: (id) => setRecent((r) => [id, ...r.filter((x) => x !== id)].slice(0, 6)),
      }}
    >
      {children}
    </Context.Provider>
  );
}
export function useShop() {
  const c = useContext(Context);
  if (!c) throw new Error("Shop provider missing");
  return c;
}

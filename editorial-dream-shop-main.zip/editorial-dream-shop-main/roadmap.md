# Storefront roadmap
- [x] Establish original identity, imagery, typed mock catalog and shared shopping state.
- [x] Build editorial home, shared navigation, footer and collection/product shopping experiences.
- [x] Build search, wishlist, bag and simulated checkout/account journeys.
- [x] Build journal and informational pages.
- [x] Verify shopping interactions, routes and mobile layouts.

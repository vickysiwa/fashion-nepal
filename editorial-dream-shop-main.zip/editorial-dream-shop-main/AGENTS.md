<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Storefront architecture
- Keep the existing TanStack Start file router; page-specific metadata belongs on each leaf route so all shopping and editorial views are independently shareable.
- Keep typed product, navigation and editorial data plus lookup helpers in the frontend catalog module; presentation must use these helpers so a future data provider can replace mock data without redesigning pages.
- Share shopping state through a root provider with validated, hydration-safe local storage; no server services are used in the demonstration phase.
- Compose pages from reusable storefront components and the existing Radix-based UI controls; global visual roles live in semantic CSS tokens.
- Keep journal listing as an index leaf rather than a content-bearing parent so articles do not mount beneath the listing.
